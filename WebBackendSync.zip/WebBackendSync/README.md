# Risk Management Platform API

Это серверная часть (бэкенд) для системы управления рисками, разработанная на Flask с использованием PostgreSQL.

## Функциональность

- Аутентификация и авторизация пользователей с разными ролями
- Управление рисками различных категорий (финансовые, операционные, юридические, стратегические, репутационные)
- Скрапинг законодательной информации и новостей
- Моделирование и симуляция рисков
- Аналитика и отчеты по рискам
- Система уведомлений о новых рисках, законодательных изменениях и новостях
- Управление документами

## Требования

- Python 3.11 или выше
- PostgreSQL 13 или выше
- Docker и Docker Compose (для развертывания в контейнерах)

## Развертывание

### Развертывание с помощью Docker

1. Клонируйте репозиторий:
   ```
   git clone <URL_репозитория>
   cd risk-management-api
   ```

2. Создайте файл `.env` на основе `.env.example`:
   ```
   cp .env.example .env
   ```

3. Отредактируйте файл `.env`, указав ваши настройки

4. Запустите приложение с помощью Docker Compose:
   ```
   docker-compose up -d
   ```

5. Инициализируйте базу данных (если первый запуск):
   ```
   docker-compose exec api python scripts/init_db.py
   ```

Приложение будет доступно по адресу: `http://ваш_сервер:5000`

### Развертывание без Docker

1. Клонируйте репозиторий:
   ```
   git clone <URL_репозитория>
   cd risk-management-api
   ```

2. Создайте и активируйте виртуальное окружение:
   ```
   python -m venv venv
   source venv/bin/activate  # На Windows: venv\Scripts\activate
   ```

3. Установите зависимости:
   ```
   pip install -r deployment_requirements.txt
   ```

4. Создайте файл `.env` на основе `.env.example` и настройте переменные окружения

5. Инициализируйте базу данных:
   ```
   python scripts/init_db.py
   ```

6. Запустите приложение с помощью Gunicorn:
   ```
   gunicorn --bind 0.0.0.0:5000 --workers 3 main:app
   ```

## API Endpoints

### Аутентификация

- `POST /api/auth/register` - Регистрация нового пользователя
- `POST /api/auth/login` - Вход в систему и получение JWT токенов
- `POST /api/auth/refresh` - Обновление JWT токена
- `POST /api/auth/logout` - Выход из системы
- `GET /api/auth/me` - Получение информации о текущем пользователе
- `PUT /api/auth/me` - Обновление профиля текущего пользователя
- `POST /api/auth/change-password` - Изменение пароля

### Риски

- `GET /api/risks` - Получение списка рисков
- `POST /api/risks` - Создание нового риска
- `GET /api/risks/<id>` - Получение информации о риске
- `PUT /api/risks/<id>` - Обновление риска
- `DELETE /api/risks/<id>` - Удаление риска

### Законодательство

- `GET /api/legislation` - Получение списка законодательных документов
- `POST /api/legislation` - Добавление законодательного документа
- `GET /api/legislation/<id>` - Получение информации о законодательном документе
- `PUT /api/legislation/<id>` - Обновление законодательного документа
- `DELETE /api/legislation/<id>` - Удаление законодательного документа

### Скрапинг

- `POST /api/scraper/legislation` - Скрапинг законодательной информации с указанного URL
- `POST /api/scraper/news` - Скрапинг новостей с указанного URL
- `POST /api/scraper/legislation/batch` - Пакетный скрапинг законодательной информации
- `POST /api/scraper/news/batch` - Пакетный скрапинг новостей

### Аналитика

- `POST /api/analytics/risk-aggregation` - Получение агрегированных данных по рискам
- `POST /api/analytics/risk-trends` - Получение трендов рисков
- `POST /api/analytics/risk-heatmap` - Получение данных для тепловой карты рисков
- `POST /api/analytics/top-risks` - Получение топ-рисков
- `GET /api/analytics/dashboard-summary` - Получение сводки для дашборда

### Уведомления

- `GET /api/notifications` - Получение списка уведомлений
- `PUT /api/notifications/<id>/read` - Отметка уведомления как прочитанного
- `POST /api/notifications/read-all` - Отметка всех уведомлений как прочитанных

### Документы

- `GET /api/documents` - Получение списка документов
- `POST /api/documents` - Загрузка нового документа
- `GET /api/documents/<id>` - Получение информации о документе
- `GET /api/documents/<id>/download` - Скачивание документа
- `DELETE /api/documents/<id>` - Удаление документа

## Разработка

1. Настройте пре-коммит хуки:
   ```
   pip install pre-commit
   pre-commit install
   ```

2. Запустите тесты:
   ```
   pytest
   ```

3. Запустите в режиме разработки:
   ```
   python main.py
   ```