from flask import request, jsonify
from functools import wraps
import time
from collections import defaultdict
import threading
import logging

logger = logging.getLogger(__name__)

# Simple in-memory storage for rate limiting
class RateLimitStore:
    def __init__(self, window_size=60):
        self.window_size = window_size  # Time window in seconds
        self.storage = defaultdict(list)
        self.lock = threading.Lock()
        
        # Start a cleanup thread
        self.cleanup_thread = threading.Thread(target=self._cleanup_expired, daemon=True)
        self.cleanup_thread.start()
    
    def add_request(self, key):
        """Record a request for a key."""
        with self.lock:
            current_time = time.time()
            self.storage[key].append(current_time)
    
    def get_request_count(self, key):
        """Get the count of requests within the time window for a key."""
        with self.lock:
            current_time = time.time()
            # Filter out requests older than the window size
            valid_requests = [t for t in self.storage[key] if current_time - t <= self.window_size]
            self.storage[key] = valid_requests
            return len(valid_requests)
    
    def _cleanup_expired(self):
        """Periodically clean up expired entries."""
        while True:
            time.sleep(60)  # Run cleanup every minute
            try:
                current_time = time.time()
                with self.lock:
                    for key in list(self.storage.keys()):
                        valid_requests = [t for t in self.storage[key] if current_time - t <= self.window_size]
                        if valid_requests:
                            self.storage[key] = valid_requests
                        else:
                            del self.storage[key]
            except Exception as e:
                logger.error(f"Error in rate limit cleanup: {str(e)}")

# Create a global rate limiter instance
rate_limiter = RateLimitStore()

def rate_limit(limit=100, window=60, key_func=None):
    """
    Rate limiting decorator for API endpoints.
    
    Args:
        limit: Maximum number of requests allowed in the time window
        window: Time window in seconds
        key_func: Function to generate a key from the request (defaults to IP address)
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get the rate limit key
            if key_func:
                key = key_func(request)
            else:
                key = request.remote_addr
                
            # Add request to rate limiter
            rate_limiter.add_request(key)
            
            # Check if rate limit exceeded
            request_count = rate_limiter.get_request_count(key)
            if request_count > limit:
                logger.warning(f"Rate limit exceeded for {key}: {request_count} requests in {window} seconds")
                return jsonify({
                    'error': 'Too many requests',
                    'message': f'Rate limit of {limit} requests per {window} seconds exceeded'
                }), 429
                
            # Set rate limit headers
            response = f(*args, **kwargs)
            
            # If response is a tuple (typical for JSON responses with status code)
            if isinstance(response, tuple) and len(response) >= 2:
                data, status_code = response[0], response[1]
                headers = {}
                if len(response) >= 3:
                    headers = response[2]
                    
                headers['X-RateLimit-Limit'] = str(limit)
                headers['X-RateLimit-Remaining'] = str(max(0, limit - request_count))
                headers['X-RateLimit-Reset'] = str(int(time.time() + window))
                
                return data, status_code, headers
            
            # Otherwise, it's a direct response object
            return response
                
        return decorated_function
    return decorator
