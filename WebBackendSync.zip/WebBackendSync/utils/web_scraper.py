import trafilatura
import logging
from datetime import datetime
from models import Legislation, News, db, NotificationType
from services.notification_service import create_notification_for_all_users

logger = logging.getLogger(__name__)

def get_website_text_content(url):
    """
    Extract the main text content of a website.
    
    Args:
        url (str): The URL of the website to scrape
        
    Returns:
        str: The extracted text content
    """
    try:
        downloaded = trafilatura.fetch_url(url)
        text = trafilatura.extract(downloaded)
        return text
    except Exception as e:
        logger.error(f"Error extracting text from {url}: {str(e)}")
        return None

def scrape_legislation_updates(url, jurisdiction=None, auto_save=False):
    """
    Scrape legislation updates from a given URL.
    
    Args:
        url (str): The URL to scrape for legislation updates
        jurisdiction (str, optional): The jurisdiction for the scraped legislation
        auto_save (bool, optional): Whether to automatically save to database
        
    Returns:
        dict: The scraped legislation data, or None if failed
    """
    try:
        content = get_website_text_content(url)
        if not content:
            return None
        
        # Extract title - first line or first sentence
        lines = content.split('\n')
        title = lines[0] if lines else "Unnamed legislation"
        
        # Rest of the content is description
        description = '\n'.join(lines[1:]) if len(lines) > 1 else ""
        
        # Create legislation data
        legislation_data = {
            "name": title,
            "description": description,
            "jurisdiction": jurisdiction,
            "effective_date": datetime.now().date(),  # Use current date as default
            "citation": "",
            "url": url
        }
        
        if auto_save:
            legislation = Legislation(**legislation_data)
            db.session.add(legislation)
            db.session.commit()
            logger.info(f"Saved new legislation: {title}")
            
            # Create notification for all users
            create_notification_for_all_users(
                message=f"New legislation update: {title}",
                notification_type=NotificationType.COMPLIANCE_UPDATE
            )
        
        return legislation_data
    except Exception as e:
        logger.error(f"Error scraping legislation from {url}: {str(e)}")
        return None

def scrape_news_updates(url, source=None, auto_save=False):
    """
    Scrape news updates from a given URL.
    
    Args:
        url (str): The URL to scrape for news
        source (str, optional): The source for the scraped news
        auto_save (bool, optional): Whether to automatically save to database
        
    Returns:
        dict: The scraped news data, or None if failed
    """
    try:
        content = get_website_text_content(url)
        if not content:
            return None
        
        # Extract title - first line or first sentence
        lines = content.split('\n')
        title = lines[0] if lines else "Unnamed news item"
        
        # Rest of the content is description
        content_text = '\n'.join(lines[1:]) if len(lines) > 1 else ""
        
        # Create news data
        news_data = {
            "title": title,
            "content": content_text,
            "source": source or "Web scraper",
            "publication_date": datetime.now(),
            "url": url
        }
        
        if auto_save:
            news = News(**news_data)
            db.session.add(news)
            db.session.commit()
            logger.info(f"Saved new news item: {title}")
            
            # Create notification for all users
            create_notification_for_all_users(
                message=f"New risk-related news item: {title}",
                notification_type=NotificationType.NEWS_ALERT
            )
        
        return news_data
    except Exception as e:
        logger.error(f"Error scraping news from {url}: {str(e)}")
        return None

def batch_scrape_legislation(url_list, jurisdiction=None):
    """
    Perform batch scraping of legislation from multiple URLs.
    
    Args:
        url_list (list): List of URLs to scrape
        jurisdiction (str, optional): The jurisdiction for all legislation
        
    Returns:
        list: Successfully scraped legislation data
    """
    results = []
    for url in url_list:
        result = scrape_legislation_updates(url, jurisdiction, auto_save=True)
        if result:
            results.append(result)
    
    return results

def batch_scrape_news(url_list, source=None):
    """
    Perform batch scraping of news from multiple URLs.
    
    Args:
        url_list (list): List of URLs to scrape
        source (str, optional): The source for all news items
        
    Returns:
        list: Successfully scraped news data
    """
    results = []
    for url in url_list:
        result = scrape_news_updates(url, source, auto_save=True)
        if result:
            results.append(result)
    
    return results