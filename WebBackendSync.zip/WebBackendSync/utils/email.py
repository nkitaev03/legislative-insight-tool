import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import current_app, render_template_string
import logging

logger = logging.getLogger(__name__)

def send_email(recipient, subject, body, html=None):
    """Send an email to a recipient."""
    try:
        # Configure email
        message = MIMEMultipart('alternative')
        message['From'] = current_app.config['MAIL_DEFAULT_SENDER']
        message['To'] = recipient
        message['Subject'] = subject
        
        # Attach plain text and HTML parts
        message.attach(MIMEText(body, 'plain'))
        if html:
            message.attach(MIMEText(html, 'html'))
        
        # Connect to SMTP server
        smtp = smtplib.SMTP(
            current_app.config['MAIL_SERVER'],
            current_app.config['MAIL_PORT']
        )
        
        # Use TLS if configured
        if current_app.config['MAIL_USE_TLS']:
            smtp.starttls()
        
        # Login if credentials are provided
        if current_app.config['MAIL_USERNAME'] and current_app.config['MAIL_PASSWORD']:
            smtp.login(
                current_app.config['MAIL_USERNAME'],
                current_app.config['MAIL_PASSWORD']
            )
        
        # Send email
        smtp.sendmail(
            current_app.config['MAIL_DEFAULT_SENDER'],
            recipient,
            message.as_string()
        )
        
        # Close connection
        smtp.quit()
        logger.info(f"Email sent to {recipient}: {subject}")
        return True
    except Exception as e:
        logger.error(f"Failed to send email to {recipient}: {str(e)}")
        return False

def send_risk_notification(user, risk):
    """Send a risk notification email to a user."""
    subject = f"Risk Alert: {risk.title}"
    
    # Plain text version
    body = f"""
    Dear {user.first_name or user.username},
    
    A new risk has been identified that requires your attention:
    
    Title: {risk.title}
    Severity: {risk.severity.value}
    Likelihood: {risk.likelihood.value}
    Risk Score: {risk.risk_score}
    
    Please log in to the Risk Management Platform to review this risk.
    
    Regards,
    Risk Management Team
    """
    
    # HTML version
    html = render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .risk-details { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
            .severity-high, .severity-critical { color: #d9534f; }
            .severity-medium { color: #f0ad4e; }
            .severity-low { color: #5bc0de; }
        </style>
    </head>
    <body>
        <h2>Risk Alert</h2>
        <p>Dear {{ user.first_name or user.username }},</p>
        <p>A new risk has been identified that requires your attention:</p>
        
        <div class="risk-details">
            <h3>{{ risk.title }}</h3>
            <p><strong>Severity:</strong> <span class="severity-{{ risk.severity.value }}">{{ risk.severity.value }}</span></p>
            <p><strong>Likelihood:</strong> {{ risk.likelihood.value }}</p>
            <p><strong>Risk Score:</strong> {{ "%.2f"|format(risk.risk_score) }}</p>
            <p><strong>Description:</strong> {{ risk.description }}</p>
        </div>
        
        <p>Please log in to the Risk Management Platform to review this risk.</p>
        
        <p>Regards,<br>Risk Management Team</p>
    </body>
    </html>
    """, user=user, risk=risk)
    
    return send_email(user.email, subject, body, html)

def send_password_reset(user, reset_link):
    """Send a password reset email to a user."""
    subject = "Password Reset Request"
    
    # Plain text version
    body = f"""
    Dear {user.first_name or user.username},
    
    We received a request to reset your password for the Risk Management Platform.
    To reset your password, please click on the link below:
    
    {reset_link}
    
    If you did not request a password reset, please ignore this email.
    
    Regards,
    Risk Management Team
    """
    
    # HTML version
    html = render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .button { display: inline-block; padding: 10px 20px; background-color: #428bca; 
                     color: white; text-decoration: none; border-radius: 5px; }
        </style>
    </head>
    <body>
        <h2>Password Reset Request</h2>
        <p>Dear {{ user.first_name or user.username }},</p>
        <p>We received a request to reset your password for the Risk Management Platform.</p>
        <p>To reset your password, please click on the button below:</p>
        
        <p><a class="button" href="{{ reset_link }}">Reset Password</a></p>
        
        <p>If the button doesn't work, copy and paste this link into your browser:</p>
        <p>{{ reset_link }}</p>
        
        <p>If you did not request a password reset, please ignore this email.</p>
        
        <p>Regards,<br>Risk Management Team</p>
    </body>
    </html>
    """, user=user, reset_link=reset_link)
    
    return send_email(user.email, subject, body, html)
