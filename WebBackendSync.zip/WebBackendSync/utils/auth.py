import uuid
from datetime import datetime
from functools import wraps
from flask import request, jsonify, current_app
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt_identity, jwt_required
from models import User, RefreshToken, UserRole
from app import db, jwt
import logging

logger = logging.getLogger(__name__)

def generate_access_token(user_id):
    """Generate a JWT access token for a user."""
    return create_access_token(identity=user_id)

def generate_refresh_token(user_id):
    """Generate a JWT refresh token for a user."""
    return create_refresh_token(identity=user_id)

def token_required(f):
    """Decorator for views that require authentication."""
    @wraps(f)
    @jwt_required()
    def decorated(*args, **kwargs):
        try:
            # Get the user ID from the JWT identity
            user_id = get_jwt_identity()
            
            # Get user from database
            current_user = User.query.get(int(user_id))
            if not current_user:
                return jsonify({'message': 'User not found.'}), 401
                
            # Check if user is active
            if not current_user.active:
                return jsonify({'message': 'User account is inactive.'}), 401
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return jsonify({'message': 'An error occurred during authentication.'}), 401
            
        # Pass the current user to the wrapped function
        return f(current_user, *args, **kwargs)
        
    return decorated

def role_required(*roles):
    """Decorator for views that require specific roles."""
    def decorator(f):
        @wraps(f)
        def decorated_function(current_user, *args, **kwargs):
            # Check if the user has one of the required roles
            if not current_user.role or current_user.role.value not in [role.value if isinstance(role, UserRole) else role for role in roles]:
                return jsonify({'message': 'Access denied. Insufficient permissions.'}), 403
            return f(current_user, *args, **kwargs)
        return decorated_function
    return decorator

def verify_refresh_token(refresh_token):
    """Get user identity from refresh token"""
    from flask_jwt_extended import decode_token
    try:
        # Decode the refresh token to get the identity
        decoded_token = decode_token(refresh_token)
        user_id = decoded_token['sub']
        return User.query.get(int(user_id))
    except Exception as e:
        logger.error(f"Error verifying refresh token: {str(e)}")
        return None

def revoke_user_tokens(user_id):
    """
    Revoke all refresh tokens for a user.
    
    Note: With Flask-JWT-Extended, tokens can't be easily revoked individually.
    Instead, we rely on token blacklisting which would need to be configured
    with a proper storage backend.
    """
    logger.info(f"Token revocation would be handled by JWT blacklist for user_id: {user_id}")
    pass
