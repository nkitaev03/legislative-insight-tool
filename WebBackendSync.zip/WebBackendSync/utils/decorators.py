from functools import wraps
from flask import request, jsonify
import logging
import time
from marshmallow import ValidationError

logger = logging.getLogger(__name__)

def validate_schema(schema_class):
    """
    Decorator to validate request data against a schema.
    
    Args:
        schema_class: Marshmallow schema class for validation
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            schema = schema_class()
            
            # Handle both JSON and form data
            if request.is_json:
                data = request.get_json()
            else:
                data = request.form.to_dict()
                
            # For file uploads with multipart/form-data
            if request.files:
                data.update({key: request.files[key] for key in request.files})
                
            # For query parameters
            if request.method == 'GET':
                data = request.args.to_dict()
                
            try:
                # Validate data
                validated_data = schema.load(data)
                # Pass validated data to the view function
                return f(validated_data=validated_data, *args, **kwargs)
            except ValidationError as err:
                return jsonify({
                    'error': 'Validation error',
                    'messages': err.messages
                }), 400
                
        return decorated_function
    return decorator

def timer(f):
    """Decorator to log function execution time."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        end_time = time.time()
        logger.debug(f"{f.__name__} executed in {end_time - start_time:.4f} seconds")
        return result
    return decorated_function

def log_activity(activity_type):
    """
    Decorator to log user activity.
    
    Args:
        activity_type: Type of activity (e.g., 'create', 'update', 'delete')
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(current_user, *args, **kwargs):
            logger.info(f"User {current_user.username} is performing {activity_type} operation")
            result = f(current_user, *args, **kwargs)
            
            # Log the result
            if isinstance(result, tuple) and len(result) >= 2:
                status_code = result[1]
                success = 200 <= status_code < 300
            else:
                success = True
                
            logger.info(f"User {current_user.username} {activity_type} operation {'succeeded' if success else 'failed'}")
            return result
            
        return decorated_function
    return decorator
