import os
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import current_app
import logging

logger = logging.getLogger(__name__)

def allowed_file(filename, allowed_extensions=None):
    """Check if a file has an allowed extension."""
    if allowed_extensions is None:
        allowed_extensions = current_app.config['ALLOWED_DOCUMENT_EXTENSIONS']
        
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

def save_file(file, subfolder=None):
    """Save a file to the local file system."""
    try:
        # Generate a secure filename
        original_filename = secure_filename(file.filename)
        
        # Create a unique filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_id = str(uuid.uuid4().hex[:8])
        filename = f"{timestamp}_{unique_id}_{original_filename}"
        
        # Determine the target directory
        upload_folder = current_app.config['UPLOAD_FOLDER']
        if subfolder:
            target_dir = os.path.join(upload_folder, subfolder)
        else:
            target_dir = upload_folder
            
        # Ensure the directory exists
        if not os.path.exists(target_dir):
            os.makedirs(target_dir)
            
        # Save the file
        file_path = os.path.join(target_dir, filename)
        file.save(file_path)
        
        # Get file size in bytes
        file_size = os.path.getsize(file_path)
        
        logger.info(f"File saved: {file_path}, Size: {file_size} bytes")
        
        # Return file information
        return {
            'original_filename': original_filename,
            'filename': filename,
            'file_path': file_path,
            'file_size': file_size,
            'subfolder': subfolder
        }
    except Exception as e:
        logger.error(f"Error saving file: {str(e)}")
        raise

def delete_file(file_path):
    """Delete a file from the local file system."""
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"File deleted: {file_path}")
            return True
        else:
            logger.warning(f"File not found: {file_path}")
            return False
    except Exception as e:
        logger.error(f"Error deleting file: {str(e)}")
        return False

def get_file_url(file_path, filename):
    """Generate a URL for accessing a file."""
    # This is a placeholder function for when we implement S3-compatible storage
    # For now, we return a relative path that can be used in API responses
    
    # Remove the base upload folder path to get the relative path
    upload_folder = current_app.config['UPLOAD_FOLDER']
    relative_path = file_path.replace(upload_folder, '').lstrip('/')
    
    # Return a URL path that can be used by the frontend
    return f"/api/documents/download/{relative_path}"

def get_file_extension(filename):
    """Extract the file extension from a filename."""
    if '.' in filename:
        return filename.rsplit('.', 1)[1].lower()
    return ""

def get_file_mimetype(filename):
    """Return a MIME type based on file extension."""
    extension = get_file_extension(filename)
    
    mime_types = {
        'pdf': 'application/pdf',
        'doc': 'application/msword',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls': 'application/vnd.ms-excel',
        'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'csv': 'text/csv',
        'txt': 'text/plain',
        'json': 'application/json',
        'xml': 'application/xml',
    }
    
    return mime_types.get(extension, 'application/octet-stream')
