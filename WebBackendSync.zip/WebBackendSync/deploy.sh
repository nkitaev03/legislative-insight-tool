#!/bin/bash
# Скрипт для автоматического развертывания Risk Management API на сервере

set -e

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Начинаем развертывание Risk Management API ===${NC}"

# Проверка наличия Docker и Docker Compose
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker не установлен. Установите Docker перед запуском скрипта.${NC}"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Docker Compose не установлен. Установите Docker Compose перед запуском скрипта.${NC}"
    exit 1
fi

# Проверка наличия файла .env
if [ ! -f .env ]; then
    echo -e "${YELLOW}Файл .env не найден. Создаем на основе примера...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}Пожалуйста, отредактируйте файл .env с вашими настройками перед продолжением.${NC}"
    echo -e "${YELLOW}Нажмите Enter для продолжения после редактирования или Ctrl+C для отмены.${NC}"
    read
fi

# Создание директории для загрузок, если она не существует
mkdir -p uploads
chmod 777 uploads

echo -e "${GREEN}Запускаем контейнеры...${NC}"
docker-compose up -d --build

# Ждем запуска базы данных
echo -e "${YELLOW}Ждем запуска базы данных...${NC}"
sleep 10

# Инициализация базы данных
echo -e "${GREEN}Инициализируем базу данных...${NC}"
docker-compose exec api python scripts/init_db.py

echo -e "${GREEN}=== Развертывание завершено успешно! ===${NC}"
echo -e "${GREEN}API доступно по адресу: http://localhost:5000${NC}"
echo -e "${YELLOW}Для настройки HTTPS и домена используйте Nginx (см. nginx-config.md)${NC}"