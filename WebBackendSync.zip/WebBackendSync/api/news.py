from flask import Blueprint, request, jsonify
from sqlalchemy import desc, asc, or_
from app import db
from models import News, UserRole
from schemas import NewsSchema, NewsQuerySchema
from utils import token_required, role_required, validate_schema, log_activity
import logging

logger = logging.getLogger(__name__)

news_bp = Blueprint('news', __name__)

@news_bp.route('', methods=['GET'])
@token_required
@validate_schema(NewsQuerySchema)
def get_news(current_user, validated_data):
    """Get news with filtering and pagination."""
    # Start with base query
    query = News.query
    
    # Apply filters
    if validated_data.get('source'):
        query = query.filter(News.source == validated_data['source'])
        
    if validated_data.get('published_after'):
        query = query.filter(News.publication_date >= validated_data['published_after'])
        
    if validated_data.get('published_before'):
        query = query.filter(News.publication_date <= validated_data['published_before'])
        
    if validated_data.get('search'):
        search_term = f"%{validated_data['search']}%"
        query = query.filter(
            or_(
                News.title.ilike(search_term),
                News.content.ilike(search_term),
                News.source.ilike(search_term)
            )
        )
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'publication_date')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(News, sort_by)))
    else:
        query = query.order_by(asc(getattr(News, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    news_schema = NewsSchema(many=True)
    news_items = news_schema.dump(pagination.items)
    
    return jsonify({
        'news': news_items,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@news_bp.route('', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(NewsSchema)
@log_activity('create_news')
def create_news(current_user, validated_data):
    """Create a new news item."""
    # Create news
    news = News(
        title=validated_data['title'],
        content=validated_data['content'],
        source=validated_data.get('source'),
        publication_date=validated_data.get('publication_date'),
        url=validated_data.get('url')
    )
    
    db.session.add(news)
    db.session.commit()
    
    news_schema = NewsSchema()
    return jsonify({
        'message': 'News created successfully',
        'news': news_schema.dump(news)
    }), 201

@news_bp.route('/<int:news_id>', methods=['GET'])
@token_required
def get_single_news(current_user, news_id):
    """Get a specific news item."""
    news = News.query.get_or_404(news_id)
    news_schema = NewsSchema()
    
    return jsonify(news_schema.dump(news)), 200

@news_bp.route('/<int:news_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(NewsSchema)
@log_activity('update_news')
def update_news(current_user, news_id, validated_data):
    """Update a news item."""
    news = News.query.get_or_404(news_id)
    
    # Update fields
    for field in ['title', 'content', 'source', 'publication_date', 'url']:
        if field in validated_data:
            setattr(news, field, validated_data[field])
    
    db.session.commit()
    
    news_schema = NewsSchema()
    return jsonify({
        'message': 'News updated successfully',
        'news': news_schema.dump(news)
    }), 200

@news_bp.route('/<int:news_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@log_activity('delete_news')
def delete_news(current_user, news_id):
    """Delete a news item."""
    news = News.query.get_or_404(news_id)
    
    db.session.delete(news)
    db.session.commit()
    
    return jsonify({'message': 'News deleted successfully'}), 200

@news_bp.route('/sources', methods=['GET'])
@token_required
def get_sources(current_user):
    """Get all unique news sources."""
    sources = db.session.query(News.source)\
        .filter(News.source.isnot(None))\
        .distinct()\
        .order_by(News.source)\
        .all()
    
    # Extract source values from results
    source_list = [s[0] for s in sources if s[0]]
    
    return jsonify({'sources': source_list}), 200
