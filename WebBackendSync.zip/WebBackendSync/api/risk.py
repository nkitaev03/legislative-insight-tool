from flask import Blueprint, request, jsonify
from sqlalchemy import desc, asc, func
from app import db
from models import Risk, RiskCategory, Tag, Comment, User, UserRole
from schemas import RiskSchema, RiskCategorySchema, TagSchema, CommentSchema, RiskQuerySchema
from utils import token_required, role_required, validate_schema, log_activity, send_risk_notification
import logging

logger = logging.getLogger(__name__)

risk_bp = Blueprint('risk', __name__)

# Risk Category endpoints
@risk_bp.route('/categories', methods=['GET'])
@token_required
def get_risk_categories(current_user):
    """Get all risk categories."""
    categories = RiskCategory.query.all()
    category_schema = RiskCategorySchema(many=True)
    
    return jsonify(category_schema.dump(categories)), 200

@risk_bp.route('/categories', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(RiskCategorySchema)
@log_activity('create_risk_category')
def create_risk_category(current_user, validated_data):
    """Create a new risk category."""
    # Check if category already exists
    if RiskCategory.query.filter_by(name=validated_data['name']).first():
        return jsonify({'message': 'Category already exists'}), 409
    
    # Create category
    category = RiskCategory(
        name=validated_data['name'],
        description=validated_data.get('description', '')
    )
    
    db.session.add(category)
    db.session.commit()
    
    category_schema = RiskCategorySchema()
    return jsonify({
        'message': 'Risk category created successfully',
        'category': category_schema.dump(category)
    }), 201

@risk_bp.route('/categories/<int:category_id>', methods=['GET'])
@token_required
def get_risk_category(current_user, category_id):
    """Get a specific risk category."""
    category = RiskCategory.query.get_or_404(category_id)
    category_schema = RiskCategorySchema()
    
    return jsonify(category_schema.dump(category)), 200

@risk_bp.route('/categories/<int:category_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(RiskCategorySchema)
@log_activity('update_risk_category')
def update_risk_category(current_user, category_id, validated_data):
    """Update a risk category."""
    category = RiskCategory.query.get_or_404(category_id)
    
    # Update fields
    category.name = validated_data['name']
    category.description = validated_data.get('description', category.description)
    
    db.session.commit()
    
    category_schema = RiskCategorySchema()
    return jsonify({
        'message': 'Risk category updated successfully',
        'category': category_schema.dump(category)
    }), 200

@risk_bp.route('/categories/<int:category_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@log_activity('delete_risk_category')
def delete_risk_category(current_user, category_id):
    """Delete a risk category."""
    category = RiskCategory.query.get_or_404(category_id)
    
    # Check if category is in use
    if category.risks.count() > 0:
        return jsonify({
            'message': 'Cannot delete category that is associated with risks',
            'count': category.risks.count()
        }), 400
    
    db.session.delete(category)
    db.session.commit()
    
    return jsonify({'message': 'Risk category deleted successfully'}), 200

# Tag endpoints
@risk_bp.route('/tags', methods=['GET'])
@token_required
def get_tags(current_user):
    """Get all tags."""
    tags = Tag.query.all()
    tag_schema = TagSchema(many=True)
    
    return jsonify(tag_schema.dump(tags)), 200

@risk_bp.route('/tags', methods=['POST'])
@token_required
@validate_schema(TagSchema)
@log_activity('create_tag')
def create_tag(current_user, validated_data):
    """Create a new tag."""
    # Check if tag already exists
    existing_tag = Tag.query.filter(func.lower(Tag.name) == func.lower(validated_data['name'])).first()
    if existing_tag:
        return jsonify({'message': 'Tag already exists'}), 409
    
    # Create tag
    tag = Tag(name=validated_data['name'])
    
    db.session.add(tag)
    db.session.commit()
    
    tag_schema = TagSchema()
    return jsonify({
        'message': 'Tag created successfully',
        'tag': tag_schema.dump(tag)
    }), 201

@risk_bp.route('/tags/<int:tag_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(TagSchema)
@log_activity('update_tag')
def update_tag(current_user, tag_id, validated_data):
    """Update a tag."""
    tag = Tag.query.get_or_404(tag_id)
    
    # Update name
    tag.name = validated_data['name']
    
    db.session.commit()
    
    tag_schema = TagSchema()
    return jsonify({
        'message': 'Tag updated successfully',
        'tag': tag_schema.dump(tag)
    }), 200

@risk_bp.route('/tags/<int:tag_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@log_activity('delete_tag')
def delete_tag(current_user, tag_id):
    """Delete a tag."""
    tag = Tag.query.get_or_404(tag_id)
    
    db.session.delete(tag)
    db.session.commit()
    
    return jsonify({'message': 'Tag deleted successfully'}), 200

# Risk endpoints
@risk_bp.route('', methods=['GET'])
@token_required
@validate_schema(RiskQuerySchema)
def get_risks(current_user, validated_data):
    """Get risks with filtering and pagination."""
    # Start with base query
    query = Risk.query
    
    # Apply filters
    if validated_data.get('status'):
        query = query.filter(Risk.status == validated_data['status'])
        
    if validated_data.get('severity'):
        query = query.filter(Risk.severity == validated_data['severity'])
        
    if validated_data.get('likelihood'):
        query = query.filter(Risk.likelihood == validated_data['likelihood'])
        
    if validated_data.get('owner_id'):
        query = query.filter(Risk.owner_id == validated_data['owner_id'])
        
    if validated_data.get('category_id'):
        query = query.join(Risk.categories).filter(RiskCategory.id == validated_data['category_id'])
        
    if validated_data.get('tag_id'):
        query = query.join(Risk.tags).filter(Tag.id == validated_data['tag_id'])
        
    if validated_data.get('min_risk_score'):
        query = query.filter(Risk.risk_score >= validated_data['min_risk_score'])
        
    if validated_data.get('max_risk_score'):
        query = query.filter(Risk.risk_score <= validated_data['max_risk_score'])
        
    if validated_data.get('identified_after'):
        query = query.filter(Risk.identified_date >= validated_data['identified_after'])
        
    if validated_data.get('identified_before'):
        query = query.filter(Risk.identified_date <= validated_data['identified_before'])
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'created_at')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Risk, sort_by)))
    else:
        query = query.order_by(asc(getattr(Risk, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    risk_schema = RiskSchema(many=True)
    risks = risk_schema.dump(pagination.items)
    
    return jsonify({
        'risks': risks,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@risk_bp.route('', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(RiskSchema)
@log_activity('create_risk')
def create_risk(current_user, validated_data):
    """Create a new risk."""
    # Create risk object
    risk = Risk(
        title=validated_data['title'],
        description=validated_data['description'],
        status=validated_data.get('status'),
        severity=validated_data.get('severity'),
        likelihood=validated_data.get('likelihood'),
        impact_score=validated_data.get('impact_score', 0.0),
        mitigation_plan=validated_data.get('mitigation_plan', ''),
        owner_id=validated_data.get('owner_id', current_user.id)
    )
    
    # Add categories if provided
    if 'categories' in validated_data and validated_data['categories']:
        for category_data in validated_data['categories']:
            category = RiskCategory.query.get(category_data['id'])
            if category:
                risk.categories.append(category)
    
    # Add tags if provided
    if 'tags' in validated_data and validated_data['tags']:
        for tag_data in validated_data['tags']:
            tag = Tag.query.get(tag_data['id'])
            if tag:
                risk.tags.append(tag)
            else:
                # Create new tag if it doesn't exist
                new_tag = Tag(name=tag_data['name'])
                db.session.add(new_tag)
                risk.tags.append(new_tag)
    
    db.session.add(risk)
    db.session.commit()
    
    # Send notification to the owner if it's not the current user
    if risk.owner_id != current_user.id:
        owner = User.query.get(risk.owner_id)
        if owner:
            send_risk_notification(owner, risk)
    
    risk_schema = RiskSchema()
    return jsonify({
        'message': 'Risk created successfully',
        'risk': risk_schema.dump(risk)
    }), 201

@risk_bp.route('/<int:risk_id>', methods=['GET'])
@token_required
def get_risk(current_user, risk_id):
    """Get a specific risk with details."""
    risk = Risk.query.get_or_404(risk_id)
    risk_schema = RiskSchema()
    
    return jsonify(risk_schema.dump(risk)), 200

@risk_bp.route('/<int:risk_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(RiskSchema)
@log_activity('update_risk')
def update_risk(current_user, risk_id, validated_data):
    """Update a risk."""
    risk = Risk.query.get_or_404(risk_id)
    
    # Check permission - only allow updates by owner or admin/risk manager
    if risk.owner_id != current_user.id and current_user.role not in [UserRole.ADMIN, UserRole.RISK_MANAGER]:
        return jsonify({'message': 'You do not have permission to update this risk'}), 403
    
    # Update fields
    for field in ['title', 'description', 'status', 'severity', 'likelihood', 
                 'impact_score', 'mitigation_plan', 'resolution_date']:
        if field in validated_data:
            setattr(risk, field, validated_data[field])
    
    # Update owner if provided and user is admin or risk manager
    if 'owner_id' in validated_data and current_user.role in [UserRole.ADMIN, UserRole.RISK_MANAGER]:
        risk.owner_id = validated_data['owner_id']
    
    # Update categories if provided
    if 'categories' in validated_data:
        risk.categories = []
        for category_data in validated_data['categories']:
            category = RiskCategory.query.get(category_data['id'])
            if category:
                risk.categories.append(category)
    
    # Update tags if provided
    if 'tags' in validated_data:
        risk.tags = []
        for tag_data in validated_data['tags']:
            tag = Tag.query.get(tag_data['id'])
            if tag:
                risk.tags.append(tag)
            else:
                # Create new tag if it doesn't exist
                new_tag = Tag(name=tag_data['name'])
                db.session.add(new_tag)
                risk.tags.append(new_tag)
    
    db.session.commit()
    
    risk_schema = RiskSchema()
    return jsonify({
        'message': 'Risk updated successfully',
        'risk': risk_schema.dump(risk)
    }), 200

@risk_bp.route('/<int:risk_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@log_activity('delete_risk')
def delete_risk(current_user, risk_id):
    """Delete a risk."""
    risk = Risk.query.get_or_404(risk_id)
    
    db.session.delete(risk)
    db.session.commit()
    
    return jsonify({'message': 'Risk deleted successfully'}), 200

# Comment endpoints
@risk_bp.route('/<int:risk_id>/comments', methods=['GET'])
@token_required
def get_risk_comments(current_user, risk_id):
    """Get all comments for a risk."""
    # Check if risk exists
    risk = Risk.query.get_or_404(risk_id)
    
    comments = Comment.query.filter_by(risk_id=risk_id).order_by(Comment.created_at.desc()).all()
    comment_schema = CommentSchema(many=True)
    
    return jsonify(comment_schema.dump(comments)), 200

@risk_bp.route('/<int:risk_id>/comments', methods=['POST'])
@token_required
@validate_schema(CommentSchema)
@log_activity('create_comment')
def create_risk_comment(current_user, risk_id, validated_data):
    """Add a comment to a risk."""
    # Check if risk exists
    risk = Risk.query.get_or_404(risk_id)
    
    # Create comment
    comment = Comment(
        content=validated_data['content'],
        author_id=current_user.id,
        risk_id=risk_id
    )
    
    db.session.add(comment)
    db.session.commit()
    
    comment_schema = CommentSchema()
    return jsonify({
        'message': 'Comment added successfully',
        'comment': comment_schema.dump(comment)
    }), 201

@risk_bp.route('/<int:risk_id>/comments/<int:comment_id>', methods=['PUT'])
@token_required
@validate_schema(CommentSchema)
@log_activity('update_comment')
def update_risk_comment(current_user, risk_id, comment_id, validated_data):
    """Update a comment."""
    # Check if comment exists and belongs to the risk
    comment = Comment.query.filter_by(id=comment_id, risk_id=risk_id).first_or_404()
    
    # Check if current user is the author
    if comment.author_id != current_user.id and current_user.role != UserRole.ADMIN:
        return jsonify({'message': 'You do not have permission to update this comment'}), 403
    
    # Update content
    comment.content = validated_data['content']
    
    db.session.commit()
    
    comment_schema = CommentSchema()
    return jsonify({
        'message': 'Comment updated successfully',
        'comment': comment_schema.dump(comment)
    }), 200

@risk_bp.route('/<int:risk_id>/comments/<int:comment_id>', methods=['DELETE'])
@token_required
@log_activity('delete_comment')
def delete_risk_comment(current_user, risk_id, comment_id):
    """Delete a comment."""
    # Check if comment exists and belongs to the risk
    comment = Comment.query.filter_by(id=comment_id, risk_id=risk_id).first_or_404()
    
    # Check if current user is the author or an admin
    if comment.author_id != current_user.id and current_user.role != UserRole.ADMIN:
        return jsonify({'message': 'You do not have permission to delete this comment'}), 403
    
    db.session.delete(comment)
    db.session.commit()
    
    return jsonify({'message': 'Comment deleted successfully'}), 200
