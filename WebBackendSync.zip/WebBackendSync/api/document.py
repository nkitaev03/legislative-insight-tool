from flask import Blueprint, request, jsonify, send_from_directory, current_app
from werkzeug.utils import secure_filename
import os
from app import db
from models import Document, Tag, User, UserRole, DocumentStatus
from schemas import DocumentSchema, DocumentQuerySchema, DocumentUpdateSchema
from utils import token_required, role_required, validate_schema, log_activity
from utils import allowed_file, save_file, delete_file, get_file_url, get_file_mimetype
from sqlalchemy import desc, asc, or_
from services.document_service import create_document, update_document_metadata
import logging

logger = logging.getLogger(__name__)

document_bp = Blueprint('document', __name__)

@document_bp.route('', methods=['GET'])
@token_required
@validate_schema(DocumentQuerySchema)
def get_documents(current_user, validated_data):
    """Get documents with filtering and pagination."""
    # Start with base query
    query = Document.query
    
    # Apply filters
    if validated_data.get('status'):
        query = query.filter(Document.status == validated_data['status'])
        
    if validated_data.get('owner_id'):
        query = query.filter(Document.owner_id == validated_data['owner_id'])
        
    if validated_data.get('risk_id'):
        query = query.filter(Document.risk_id == validated_data['risk_id'])
        
    if validated_data.get('legislation_id'):
        query = query.filter(Document.legislation_id == validated_data['legislation_id'])
        
    if validated_data.get('tag_id'):
        query = query.join(Document.tags).filter(Tag.id == validated_data['tag_id'])
        
    if validated_data.get('file_type'):
        query = query.filter(Document.file_type == validated_data['file_type'])
        
    if validated_data.get('created_after'):
        query = query.filter(Document.created_at >= validated_data['created_after'])
        
    if validated_data.get('created_before'):
        query = query.filter(Document.created_at <= validated_data['created_before'])
        
    if validated_data.get('search'):
        search_term = f"%{validated_data['search']}%"
        query = query.filter(
            or_(
                Document.title.ilike(search_term),
                Document.description.ilike(search_term),
                Document.filename.ilike(search_term)
            )
        )
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'created_at')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Document, sort_by)))
    else:
        query = query.order_by(asc(getattr(Document, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    document_schema = DocumentSchema(many=True)
    documents = document_schema.dump(pagination.items)
    
    # Add download URL to each document
    for doc in documents:
        doc['download_url'] = get_file_url(doc['file_path'], doc['filename'])
    
    return jsonify({
        'documents': documents,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@document_bp.route('', methods=['POST'])
@token_required
@log_activity('upload_document')
def upload_document(current_user):
    """Upload a new document."""
    # Check if the request has the file part
    if 'file' not in request.files:
        return jsonify({'message': 'No file provided'}), 400
        
    file = request.files['file']
    
    # Check if the file has a name
    if file.filename == '':
        return jsonify({'message': 'No file selected'}), 400
        
    # Check if the file is allowed
    if not allowed_file(file.filename):
        return jsonify({
            'message': f'File type not allowed. Allowed types: {", ".join(current_app.config["ALLOWED_DOCUMENT_EXTENSIONS"])}'
        }), 400
    
    # Get form data
    title = request.form.get('title')
    description = request.form.get('description', '')
    risk_id = request.form.get('risk_id')
    legislation_id = request.form.get('legislation_id')
    status = request.form.get('status', DocumentStatus.DRAFT.value)
    
    if not title:
        return jsonify({'message': 'Title is required'}), 400
    
    try:
        # Save the file
        file_info = save_file(file)
        
        # Create document in database
        document = create_document(
            title=title,
            description=description,
            filename=file_info['filename'],
            original_filename=file_info['original_filename'],
            file_path=file_info['file_path'],
            file_size=file_info['file_size'],
            file_type=os.path.splitext(file.filename)[1][1:].lower(),
            status=status,
            owner_id=current_user.id,
            risk_id=risk_id,
            legislation_id=legislation_id
        )
        
        # Process tags if provided
        tags = request.form.get('tags', '')
        if tags:
            tag_names = [t.strip() for t in tags.split(',') if t.strip()]
            for tag_name in tag_names:
                # Find or create tag
                tag = Tag.query.filter_by(name=tag_name).first()
                if not tag:
                    tag = Tag(name=tag_name)
                    db.session.add(tag)
                
                # Add tag to document
                document.tags.append(tag)
            
            db.session.commit()
        
        document_schema = DocumentSchema()
        response_data = document_schema.dump(document)
        response_data['download_url'] = get_file_url(document.file_path, document.filename)
        
        return jsonify({
            'message': 'Document uploaded successfully',
            'document': response_data
        }), 201
        
    except Exception as e:
        logger.error(f"Error uploading document: {str(e)}")
        return jsonify({'message': f'Error uploading document: {str(e)}'}), 500

@document_bp.route('/<int:document_id>', methods=['GET'])
@token_required
def get_document(current_user, document_id):
    """Get document details."""
    document = Document.query.get_or_404(document_id)
    
    document_schema = DocumentSchema()
    response_data = document_schema.dump(document)
    response_data['download_url'] = get_file_url(document.file_path, document.filename)
    
    return jsonify(response_data), 200

@document_bp.route('/<int:document_id>', methods=['PUT'])
@token_required
@validate_schema(DocumentUpdateSchema)
@log_activity('update_document')
def update_document_metadata_endpoint(current_user, document_id, validated_data):
    """Update document metadata."""
    document = Document.query.get_or_404(document_id)
    
    # Check permissions
    if document.owner_id != current_user.id and current_user.role not in [UserRole.ADMIN, UserRole.RISK_MANAGER]:
        return jsonify({'message': 'You do not have permission to update this document'}), 403
    
    try:
        updated_document = update_document_metadata(
            document=document,
            title=validated_data.get('title'),
            description=validated_data.get('description'),
            status=validated_data.get('status'),
            risk_id=validated_data.get('risk_id'),
            legislation_id=validated_data.get('legislation_id'),
            tags=validated_data.get('tags')
        )
        
        document_schema = DocumentSchema()
        response_data = document_schema.dump(updated_document)
        response_data['download_url'] = get_file_url(updated_document.file_path, updated_document.filename)
        
        return jsonify({
            'message': 'Document updated successfully',
            'document': response_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error updating document: {str(e)}")
        return jsonify({'message': f'Error updating document: {str(e)}'}), 500

@document_bp.route('/<int:document_id>', methods=['DELETE'])
@token_required
@log_activity('delete_document')
def delete_document_endpoint(current_user, document_id):
    """Delete a document."""
    document = Document.query.get_or_404(document_id)
    
    # Check permissions
    if document.owner_id != current_user.id and current_user.role not in [UserRole.ADMIN, UserRole.RISK_MANAGER]:
        return jsonify({'message': 'You do not have permission to delete this document'}), 403
    
    try:
        # Delete the file from storage
        delete_file(document.file_path)
        
        # Delete from database
        db.session.delete(document)
        db.session.commit()
        
        return jsonify({'message': 'Document deleted successfully'}), 200
        
    except Exception as e:
        logger.error(f"Error deleting document: {str(e)}")
        return jsonify({'message': f'Error deleting document: {str(e)}'}), 500

@document_bp.route('/download/<path:filename>', methods=['GET'])
@token_required
def download_document(current_user, filename):
    """Download a document."""
    try:
        # Get document by filename
        document = Document.query.filter_by(filename=filename).first_or_404()
        
        # Get the directory containing the file
        directory = os.path.dirname(document.file_path)
        base_filename = os.path.basename(document.file_path)
        
        # Set content disposition header for the original filename
        headers = {
            'Content-Disposition': f'attachment; filename="{document.filename}"',
            'Content-Type': get_file_mimetype(document.filename)
        }
        
        return send_from_directory(
            directory, 
            base_filename,
            as_attachment=True,
            download_name=document.filename,
            mimetype=get_file_mimetype(document.filename)
        )
        
    except Exception as e:
        logger.error(f"Error downloading document: {str(e)}")
        return jsonify({'message': f'Error downloading document: {str(e)}'}), 500

@document_bp.route('/types', methods=['GET'])
@token_required
def get_document_types(current_user):
    """Get all unique document types."""
    types = db.session.query(Document.file_type)\
        .filter(Document.file_type.isnot(None))\
        .distinct()\
        .order_by(Document.file_type)\
        .all()
    
    # Extract type values from results
    type_list = [t[0] for t in types if t[0]]
    
    return jsonify({'document_types': type_list}), 200
