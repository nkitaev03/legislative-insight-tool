from flask import Blueprint, request, jsonify
from sqlalchemy import desc, asc, or_, func
from app import db
from models import Legislation, UserRole
from schemas import LegislationSchema, LegislationQuerySchema
from utils import token_required, role_required, validate_schema, log_activity
import logging

logger = logging.getLogger(__name__)

legislation_bp = Blueprint('legislation', __name__)

@legislation_bp.route('', methods=['GET'])
@token_required
@validate_schema(LegislationQuerySchema)
def get_legislation(current_user, validated_data):
    """Get legislation with filtering and pagination."""
    # Start with base query
    query = Legislation.query
    
    # Apply filters
    if validated_data.get('jurisdiction'):
        query = query.filter(Legislation.jurisdiction == validated_data['jurisdiction'])
        
    if validated_data.get('effective_after'):
        query = query.filter(Legislation.effective_date >= validated_data['effective_after'])
        
    if validated_data.get('effective_before'):
        query = query.filter(Legislation.effective_date <= validated_data['effective_before'])
        
    if validated_data.get('search'):
        search_term = f"%{validated_data['search']}%"
        query = query.filter(
            or_(
                Legislation.name.ilike(search_term),
                Legislation.description.ilike(search_term),
                Legislation.citation.ilike(search_term)
            )
        )
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'created_at')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Legislation, sort_by)))
    else:
        query = query.order_by(asc(getattr(Legislation, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    legislation_schema = LegislationSchema(many=True)
    legislations = legislation_schema.dump(pagination.items)
    
    return jsonify({
        'legislation': legislations,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@legislation_bp.route('', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(LegislationSchema)
@log_activity('create_legislation')
def create_legislation(current_user, validated_data):
    """Create new legislation."""
    # Create legislation
    legislation = Legislation(
        name=validated_data['name'],
        description=validated_data['description'],
        jurisdiction=validated_data.get('jurisdiction'),
        effective_date=validated_data.get('effective_date'),
        citation=validated_data.get('citation'),
        url=validated_data.get('url')
    )
    
    db.session.add(legislation)
    db.session.commit()
    
    legislation_schema = LegislationSchema()
    return jsonify({
        'message': 'Legislation created successfully',
        'legislation': legislation_schema.dump(legislation)
    }), 201

@legislation_bp.route('/<int:legislation_id>', methods=['GET'])
@token_required
def get_single_legislation(current_user, legislation_id):
    """Get a specific legislation."""
    legislation = Legislation.query.get_or_404(legislation_id)
    legislation_schema = LegislationSchema()
    
    return jsonify(legislation_schema.dump(legislation)), 200

@legislation_bp.route('/<int:legislation_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(LegislationSchema)
@log_activity('update_legislation')
def update_legislation(current_user, legislation_id, validated_data):
    """Update legislation."""
    legislation = Legislation.query.get_or_404(legislation_id)
    
    # Update fields
    for field in ['name', 'description', 'jurisdiction', 'effective_date', 'citation', 'url']:
        if field in validated_data:
            setattr(legislation, field, validated_data[field])
    
    db.session.commit()
    
    legislation_schema = LegislationSchema()
    return jsonify({
        'message': 'Legislation updated successfully',
        'legislation': legislation_schema.dump(legislation)
    }), 200

@legislation_bp.route('/<int:legislation_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@log_activity('delete_legislation')
def delete_legislation(current_user, legislation_id):
    """Delete legislation."""
    legislation = Legislation.query.get_or_404(legislation_id)
    
    # Check if legislation has associated documents
    if legislation.documents.count() > 0:
        return jsonify({
            'message': 'Cannot delete legislation that has associated documents',
            'document_count': legislation.documents.count()
        }), 400
    
    db.session.delete(legislation)
    db.session.commit()
    
    return jsonify({'message': 'Legislation deleted successfully'}), 200

@legislation_bp.route('/jurisdictions', methods=['GET'])
@token_required
def get_jurisdictions(current_user):
    """Get all unique jurisdictions."""
    jurisdictions = db.session.query(Legislation.jurisdiction)\
        .filter(Legislation.jurisdiction.isnot(None))\
        .distinct()\
        .order_by(Legislation.jurisdiction)\
        .all()
    
    # Extract jurisdiction values from results
    jurisdiction_list = [j[0] for j in jurisdictions if j[0]]
    
    return jsonify({'jurisdictions': jurisdiction_list}), 200
