from flask import Blueprint, request, jsonify
from sqlalchemy import desc, asc
from app import db
from models import Notification, User, UserRole
from schemas import NotificationSchema, NotificationQuerySchema, NotificationUpdateSchema
from utils import token_required, role_required, validate_schema, log_activity
from services.notification_service import create_system_notification, create_user_notification
import logging

logger = logging.getLogger(__name__)

notification_bp = Blueprint('notification', __name__)

@notification_bp.route('', methods=['GET'])
@token_required
@validate_schema(NotificationQuerySchema)
def get_notifications(current_user, validated_data):
    """Get notifications for the current user with filtering and pagination."""
    # Start with base query for current user
    query = Notification.query.filter_by(recipient_id=current_user.id)
    
    # Apply filters
    if validated_data.get('is_read') is not None:
        query = query.filter(Notification.is_read == validated_data['is_read'])
        
    if validated_data.get('notification_type'):
        query = query.filter(Notification.notification_type == validated_data['notification_type'])
        
    if validated_data.get('created_after'):
        query = query.filter(Notification.created_at >= validated_data['created_after'])
        
    if validated_data.get('created_before'):
        query = query.filter(Notification.created_at <= validated_data['created_before'])
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'created_at')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Notification, sort_by)))
    else:
        query = query.order_by(asc(getattr(Notification, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    notification_schema = NotificationSchema(many=True)
    notifications = notification_schema.dump(pagination.items)
    
    return jsonify({
        'notifications': notifications,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@notification_bp.route('/<int:notification_id>', methods=['GET'])
@token_required
def get_notification(current_user, notification_id):
    """Get a specific notification."""
    # Query notification and check ownership
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.recipient_id != current_user.id:
        return jsonify({'message': 'You do not have access to this notification'}), 403
    
    notification_schema = NotificationSchema()
    return jsonify(notification_schema.dump(notification)), 200

@notification_bp.route('/<int:notification_id>', methods=['PUT'])
@token_required
@validate_schema(NotificationUpdateSchema)
@log_activity('update_notification')
def update_notification(current_user, notification_id, validated_data):
    """Update a notification (typically to mark as read/unread)."""
    # Query notification and check ownership
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.recipient_id != current_user.id:
        return jsonify({'message': 'You do not have access to this notification'}), 403
    
    # Update is_read status
    notification.is_read = validated_data['is_read']
    
    db.session.commit()
    
    notification_schema = NotificationSchema()
    return jsonify({
        'message': 'Notification updated successfully',
        'notification': notification_schema.dump(notification)
    }), 200

@notification_bp.route('/mark-all-read', methods=['POST'])
@token_required
@log_activity('mark_all_read')
def mark_all_read(current_user):
    """Mark all notifications as read for the current user."""
    # Update all unread notifications for the user
    unread_count = Notification.query.filter_by(
        recipient_id=current_user.id, is_read=False
    ).update({'is_read': True})
    
    db.session.commit()
    
    return jsonify({
        'message': 'All notifications marked as read',
        'count': unread_count
    }), 200

@notification_bp.route('/count', methods=['GET'])
@token_required
def get_notification_counts(current_user):
    """Get notification counts for the current user."""
    # Count total and unread notifications
    total_count = Notification.query.filter_by(recipient_id=current_user.id).count()
    unread_count = Notification.query.filter_by(
        recipient_id=current_user.id, is_read=False
    ).count()
    
    return jsonify({
        'total': total_count,
        'unread': unread_count
    }), 200

@notification_bp.route('', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(NotificationSchema)
@log_activity('create_notification')
def create_notification(current_user, validated_data):
    """Create a new notification (admin/risk manager only)."""
    # Create notification
    notification = create_user_notification(
        recipient_id=validated_data['recipient_id'],
        message=validated_data['message'],
        notification_type=validated_data.get('notification_type')
    )
    
    notification_schema = NotificationSchema()
    return jsonify({
        'message': 'Notification created successfully',
        'notification': notification_schema.dump(notification)
    }), 201

@notification_bp.route('/system', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN)
@validate_schema(NotificationSchema)
@log_activity('create_system_notification')
def create_system_notification_endpoint(current_user, validated_data):
    """Create a system notification for all users (admin only)."""
    # Create system notification for all active users
    message = validated_data['message']
    notification_type = validated_data.get('notification_type')
    
    # Get all active users
    active_users = User.query.filter_by(active=True).all()
    count = 0
    
    for user in active_users:
        create_system_notification(
            recipient_id=user.id,
            message=message,
            notification_type=notification_type
        )
        count += 1
    
    return jsonify({
        'message': 'System notification created for all users',
        'user_count': count
    }), 201

@notification_bp.route('/<int:notification_id>', methods=['DELETE'])
@token_required
@log_activity('delete_notification')
def delete_notification(current_user, notification_id):
    """Delete a notification."""
    # Query notification and check ownership
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.recipient_id != current_user.id and current_user.role != UserRole.ADMIN:
        return jsonify({'message': 'You do not have permission to delete this notification'}), 403
    
    db.session.delete(notification)
    db.session.commit()
    
    return jsonify({'message': 'Notification deleted successfully'}), 200
