# This package serves as a container for API blueprints

"""
API package for the Risk Management Platform.

This package contains all the API blueprints, which define the RESTful endpoints
for the different modules of the application. Each module has its own blueprint
defined in a separate file.
"""

