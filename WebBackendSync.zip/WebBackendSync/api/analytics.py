from flask import Blueprint, request, jsonify, current_app
from sqlalchemy import func, desc, extract, and_
from datetime import datetime, timedelta
from app import db
from models import Risk, RiskCategory, User, UserRole
from schemas import RiskAggregationRequestSchema, RiskTrendRequestSchema, RiskHeatmapRequestSchema, TopRisksRequestSchema
from utils import token_required, role_required, validate_schema, timer
from services.analytics_service import group_risks_by_attribute, calculate_risk_trends, generate_risk_heatmap, get_top_risks
import logging

logger = logging.getLogger(__name__)

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/aggregation', methods=['GET'])
@token_required
@validate_schema(RiskAggregationRequestSchema)
@timer
def get_risk_aggregation(current_user, validated_data):
    """
    Get risk data aggregated by a specific attribute.
    
    This endpoint allows users to view risk data grouped by different attributes
    such as severity, likelihood, status, category, owner, or tag.
    """
    try:
        results = group_risks_by_attribute(
            group_by=validated_data['group_by'],
            start_date=validated_data.get('start_date'),
            end_date=validated_data.get('end_date'),
            include_subcategories=validated_data.get('include_subcategories', False)
        )
        
        return jsonify({
            'success': True,
            'data': results
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting risk aggregation: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error performing risk aggregation: {str(e)}"
        }), 500

@analytics_bp.route('/trends', methods=['GET'])
@token_required
@validate_schema(RiskTrendRequestSchema)
@timer
def get_risk_trends(current_user, validated_data):
    """
    Get risk trends over time.
    
    This endpoint provides trend data for risks over a specified time period,
    allowing users to track how risk metrics change over time.
    """
    try:
        trend_data = calculate_risk_trends(
            time_period=validated_data['time_period'],
            metric=validated_data['metric'],
            category_id=validated_data.get('category_id'),
            status=validated_data.get('status'),
            start_date=validated_data.get('start_date'),
            end_date=validated_data.get('end_date')
        )
        
        return jsonify({
            'success': True,
            'data': trend_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting risk trends: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error calculating risk trends: {str(e)}"
        }), 500

@analytics_bp.route('/heatmap', methods=['GET'])
@token_required
@validate_schema(RiskHeatmapRequestSchema)
@timer
def get_risk_heatmap(current_user, validated_data):
    """
    Get data for a risk heatmap visualization.
    
    This endpoint provides data for creating a heatmap visualization of risks,
    typically showing likelihood vs. impact or severity.
    """
    try:
        heatmap_data = generate_risk_heatmap(
            x_axis=validated_data['x_axis'],
            y_axis=validated_data['y_axis'],
            filter_category=validated_data.get('filter_category'),
            filter_status=validated_data.get('filter_status')
        )
        
        return jsonify({
            'success': True,
            'data': heatmap_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error generating risk heatmap: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error generating risk heatmap: {str(e)}"
        }), 500

@analytics_bp.route('/top-risks', methods=['GET'])
@token_required
@validate_schema(TopRisksRequestSchema)
@timer
def get_top_risks_data(current_user, validated_data):
    """
    Get the top risks based on selected criteria.
    
    This endpoint provides a list of the top risks based on risk score,
    impact, or recency, optionally filtered by category.
    """
    try:
        top_risks_data = get_top_risks(
            limit=validated_data.get('limit', 10),
            metric=validated_data.get('metric', 'risk_score'),
            category_id=validated_data.get('category_id')
        )
        
        return jsonify({
            'success': True,
            'data': top_risks_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting top risks: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error getting top risks: {str(e)}"
        }), 500

@analytics_bp.route('/dashboard-summary', methods=['GET'])
@token_required
@timer
def get_dashboard_summary(current_user):
    """
    Get a summary of risk data for a dashboard.
    
    This endpoint provides summary statistics and metrics for displaying
    on a dashboard, giving an overview of the risk landscape.
    """
    try:
        # Get count of risks by status
        status_counts = db.session.query(
            Risk.status, func.count(Risk.id)
        ).group_by(Risk.status).all()
        status_data = {status.name: count for status, count in status_counts}
        
        # Get count of risks by severity
        severity_counts = db.session.query(
            Risk.severity, func.count(Risk.id)
        ).group_by(Risk.severity).all()
        severity_data = {severity.name: count for severity, count in severity_counts}
        
        # Get newly identified risks (last 30 days)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        new_risks_count = Risk.query.filter(Risk.identified_date >= thirty_days_ago).count()
        
        # Get average risk score
        avg_risk_score = db.session.query(func.avg(Risk.risk_score)).scalar() or 0
        
        # Get top risk categories
        top_categories = db.session.query(
            RiskCategory.name, func.count(Risk.id)
        ).join(Risk.categories).group_by(RiskCategory.name).order_by(
            func.count(Risk.id).desc()
        ).limit(5).all()
        
        category_data = [{"name": name, "count": count} for name, count in top_categories]
        
        summary_data = {
            "status_counts": status_data,
            "severity_counts": severity_data,
            "new_risks_count": new_risks_count,
            "average_risk_score": float(avg_risk_score),
            "top_categories": category_data
        }
        
        return jsonify({
            'success': True,
            'data': summary_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting dashboard summary: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error generating dashboard summary: {str(e)}"
        }), 500
