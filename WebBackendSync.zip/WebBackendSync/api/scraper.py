from flask import Blueprint, request, jsonify
from marshmallow import Schema, fields, validate
from app import db
from models import UserRole
from utils import token_required, role_required, validate_schema
from utils.web_scraper import (
    scrape_legislation_updates, 
    scrape_news_updates, 
    batch_scrape_legislation, 
    batch_scrape_news
)
import logging

logger = logging.getLogger(__name__)

scraper_bp = Blueprint('scraper', __name__)

class UrlSchema(Schema):
    url = fields.String(required=True, validate=validate.URL(error="Invalid URL format"))
    jurisdiction = fields.String(validate=validate.Length(max=64))
    source = fields.String(validate=validate.Length(max=128))
    auto_save = fields.Boolean(default=True)

class UrlListSchema(Schema):
    urls = fields.List(fields.String(validate=validate.URL(error="Invalid URL format")), required=True)
    jurisdiction = fields.String(validate=validate.Length(max=64))
    source = fields.String(validate=validate.Length(max=128))

@scraper_bp.route('/legislation', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(UrlSchema)
def scrape_legislation(current_user, validated_data):
    """
    Scrape legislation information from a website URL.
    
    This endpoint allows users to extract legislation information from a website
    and optionally save it to the database.
    """
    try:
        url = validated_data['url']
        jurisdiction = validated_data.get('jurisdiction')
        auto_save = validated_data.get('auto_save', True)
        
        result = scrape_legislation_updates(url, jurisdiction, auto_save)
        
        if not result:
            return jsonify({
                'success': False,
                'message': 'Failed to extract legislation information from the provided URL'
            }), 422
        
        return jsonify({
            'success': True,
            'message': 'Successfully extracted legislation information',
            'data': result
        }), 200
        
    except Exception as e:
        logger.error(f"Error in scrape_legislation: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error extracting legislation information: {str(e)}"
        }), 500

@scraper_bp.route('/news', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(UrlSchema)
def scrape_news(current_user, validated_data):
    """
    Scrape news information from a website URL.
    
    This endpoint allows users to extract news information from a website
    and optionally save it to the database.
    """
    try:
        url = validated_data['url']
        source = validated_data.get('source')
        auto_save = validated_data.get('auto_save', True)
        
        result = scrape_news_updates(url, source, auto_save)
        
        if not result:
            return jsonify({
                'success': False,
                'message': 'Failed to extract news information from the provided URL'
            }), 422
        
        return jsonify({
            'success': True,
            'message': 'Successfully extracted news information',
            'data': result
        }), 200
        
    except Exception as e:
        logger.error(f"Error in scrape_news: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error extracting news information: {str(e)}"
        }), 500

@scraper_bp.route('/legislation/batch', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(UrlListSchema)
def batch_legislation(current_user, validated_data):
    """
    Batch scrape legislation information from multiple website URLs.
    
    This endpoint allows users to extract legislation information from multiple websites
    and save it to the database.
    """
    try:
        urls = validated_data['urls']
        jurisdiction = validated_data.get('jurisdiction')
        
        results = batch_scrape_legislation(urls, jurisdiction)
        
        return jsonify({
            'success': True,
            'message': f'Successfully processed {len(results)} out of {len(urls)} legislation URLs',
            'data': results
        }), 200
        
    except Exception as e:
        logger.error(f"Error in batch_legislation: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error batch processing legislation: {str(e)}"
        }), 500

@scraper_bp.route('/news/batch', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER)
@validate_schema(UrlListSchema)
def batch_news(current_user, validated_data):
    """
    Batch scrape news information from multiple website URLs.
    
    This endpoint allows users to extract news information from multiple websites
    and save it to the database.
    """
    try:
        urls = validated_data['urls']
        source = validated_data.get('source')
        
        results = batch_scrape_news(urls, source)
        
        return jsonify({
            'success': True,
            'message': f'Successfully processed {len(results)} out of {len(urls)} news URLs',
            'data': results
        }), 200
        
    except Exception as e:
        logger.error(f"Error in batch_news: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error batch processing news: {str(e)}"
        }), 500