from flask import Blueprint, request, jsonify
from datetime import datetime
import time
import numpy as np
import pandas as pd
from app import db
from models import Simulation, UserRole
from schemas import SimulationSchema, SimulationExecuteSchema, SimulationQuerySchema
from utils import token_required, role_required, validate_schema, log_activity, timer
from sqlalchemy import desc, asc
import logging

logger = logging.getLogger(__name__)

simulation_bp = Blueprint('simulation', __name__)

@simulation_bp.route('', methods=['GET'])
@token_required
@validate_schema(SimulationQuerySchema)
def get_simulations(current_user, validated_data):
    """Get simulations with filtering and pagination."""
    # Start with base query
    query = Simulation.query
    
    # Apply filters
    if validated_data.get('simulation_type'):
        query = query.filter(Simulation.simulation_type == validated_data['simulation_type'])
        
    if validated_data.get('created_by'):
        query = query.filter(Simulation.created_by == validated_data['created_by'])
    
    if validated_data.get('created_after'):
        query = query.filter(Simulation.created_at >= validated_data['created_after'])
        
    if validated_data.get('created_before'):
        query = query.filter(Simulation.created_at <= validated_data['created_before'])
        
    if validated_data.get('executed') is not None:
        if validated_data['executed']:
            query = query.filter(Simulation.executed_at.isnot(None))
        else:
            query = query.filter(Simulation.executed_at.is_(None))
    
    # Apply sorting
    sort_by = validated_data.get('sort_by', 'created_at')
    sort_dir = validated_data.get('sort_dir', 'desc')
    
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Simulation, sort_by)))
    else:
        query = query.order_by(asc(getattr(Simulation, sort_by)))
    
    # Apply pagination
    page = validated_data.get('page', 1)
    per_page = validated_data.get('per_page', 20)
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Serialize results
    simulation_schema = SimulationSchema(many=True)
    simulations = simulation_schema.dump(pagination.items)
    
    return jsonify({
        'simulations': simulations,
        'pagination': {
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'current_page': pagination.page,
            'per_page': pagination.per_page,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev
        }
    }), 200

@simulation_bp.route('', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(SimulationSchema)
@log_activity('create_simulation')
def create_simulation(current_user, validated_data):
    """Create a new simulation setup."""
    # Create simulation
    simulation = Simulation(
        name=validated_data['name'],
        description=validated_data.get('description', ''),
        simulation_type=validated_data['simulation_type'],
        parameters=validated_data.get('parameters', []),
        created_by=current_user.id
    )
    
    db.session.add(simulation)
    db.session.commit()
    
    simulation_schema = SimulationSchema()
    return jsonify({
        'message': 'Simulation created successfully',
        'simulation': simulation_schema.dump(simulation)
    }), 201

@simulation_bp.route('/<int:simulation_id>', methods=['GET'])
@token_required
def get_simulation(current_user, simulation_id):
    """Get a specific simulation."""
    simulation = Simulation.query.get_or_404(simulation_id)
    simulation_schema = SimulationSchema()
    
    return jsonify(simulation_schema.dump(simulation)), 200

@simulation_bp.route('/<int:simulation_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(SimulationSchema)
@log_activity('update_simulation')
def update_simulation(current_user, simulation_id, validated_data):
    """Update a simulation setup."""
    simulation = Simulation.query.get_or_404(simulation_id)
    
    # Only allow updates to simulations that haven't been executed yet
    if simulation.executed_at is not None:
        return jsonify({'message': 'Cannot update simulation that has already been executed'}), 400
    
    # Check permissions
    if simulation.created_by != current_user.id and current_user.role != UserRole.ADMIN:
        return jsonify({'message': 'You do not have permission to update this simulation'}), 403
    
    # Update fields
    for field in ['name', 'description', 'simulation_type', 'parameters']:
        if field in validated_data:
            setattr(simulation, field, validated_data[field])
    
    db.session.commit()
    
    simulation_schema = SimulationSchema()
    return jsonify({
        'message': 'Simulation updated successfully',
        'simulation': simulation_schema.dump(simulation)
    }), 200

@simulation_bp.route('/<int:simulation_id>', methods=['DELETE'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@log_activity('delete_simulation')
def delete_simulation(current_user, simulation_id):
    """Delete a simulation."""
    simulation = Simulation.query.get_or_404(simulation_id)
    
    # Check permissions
    if simulation.created_by != current_user.id and current_user.role != UserRole.ADMIN:
        return jsonify({'message': 'You do not have permission to delete this simulation'}), 403
    
    db.session.delete(simulation)
    db.session.commit()
    
    return jsonify({'message': 'Simulation deleted successfully'}), 200

@simulation_bp.route('/execute', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN, UserRole.RISK_MANAGER, UserRole.ANALYST)
@validate_schema(SimulationExecuteSchema)
@log_activity('execute_simulation')
def execute_simulation(current_user, validated_data):
    """Execute a simulation."""
    simulation_id = validated_data['id']
    simulation = Simulation.query.get_or_404(simulation_id)
    
    # Use provided parameters or fall back to the stored ones
    parameters = validated_data.get('parameters', simulation.parameters)
    
    # Start timer
    start_time = time.time()
    
    try:
        # Execute the simulation based on type
        if simulation.simulation_type == 'monte_carlo':
            results = run_monte_carlo_simulation(parameters)
        elif simulation.simulation_type == 'scenario_analysis':
            results = run_scenario_analysis(parameters)
        elif simulation.simulation_type == 'sensitivity_analysis':
            results = run_sensitivity_analysis(parameters)
        elif simulation.simulation_type == 'stress_test':
            results = run_stress_test(parameters)
        else:
            return jsonify({'message': f'Unknown simulation type: {simulation.simulation_type}'}), 400
        
        # Calculate execution time
        execution_time = time.time() - start_time
        
        # Update simulation with results
        simulation.results = results
        simulation.executed_at = datetime.utcnow()
        simulation.execution_time = execution_time
        
        db.session.commit()
        
        simulation_schema = SimulationSchema()
        return jsonify({
            'message': 'Simulation executed successfully',
            'simulation': simulation_schema.dump(simulation)
        }), 200
        
    except Exception as e:
        logger.error(f"Error executing simulation: {str(e)}")
        return jsonify({'message': f'Error executing simulation: {str(e)}'}), 500

@timer
def run_monte_carlo_simulation(parameters):
    """
    Run a Monte Carlo simulation based on the provided parameters.
    
    This is a basic implementation that can be extended based on specific risk modeling needs.
    """
    # Extract parameters
    num_trials = 10000  # Default
    for param in parameters:
        if param['name'] == 'num_trials' and param['type'] == 'integer':
            num_trials = int(param['value'])
    
    # Initialize variables for simulation
    variables = {}
    for param in parameters:
        if param['name'].startswith('var_') and param['type'] in ['float', 'integer']:
            var_name = param['name']
            var_type = param.get('distribution', 'normal')
            var_mean = float(param.get('mean', 0))
            var_std = float(param.get('std', 1))
            var_min = float(param.get('min', float('-inf')))
            var_max = float(param.get('max', float('inf')))
            
            # Generate random values based on distribution
            if var_type == 'normal':
                values = np.random.normal(var_mean, var_std, num_trials)
            elif var_type == 'uniform':
                values = np.random.uniform(var_min, var_max, num_trials)
            elif var_type == 'triangular':
                mode = float(param.get('mode', (var_min + var_max) / 2))
                values = np.random.triangular(var_min, mode, var_max, num_trials)
            elif var_type == 'lognormal':
                values = np.random.lognormal(var_mean, var_std, num_trials)
            else:
                values = np.random.normal(var_mean, var_std, num_trials)
                
            # Apply bounds if specified
            if var_min != float('-inf'):
                values = np.maximum(values, var_min)
            if var_max != float('inf'):
                values = np.minimum(values, var_max)
                
            variables[var_name] = values
    
    # If we have a formula parameter, use it to compute the output
    formula = "sum(x)"  # Default formula
    for param in parameters:
        if param['name'] == 'formula' and param['type'] == 'string':
            formula = param['value']
    
    # Convert variables to a DataFrame for easier manipulation
    df = pd.DataFrame(variables)
    
    # Execute formula (safely with limited scope)
    # Note: This is a simplified implementation
    try:
        # Add basic statistical functions to scope
        scope = {
            'df': df,
            'sum': np.sum,
            'min': np.min,
            'max': np.max,
            'mean': np.mean,
            'median': np.median,
            'std': np.std,
            'exp': np.exp,
            'log': np.log,
            'sqrt': np.sqrt
        }
        
        # Add variables to scope
        for var_name, values in variables.items():
            scope[var_name.replace('var_', '')] = values
        
        # Evaluate formula
        result = eval(formula, {"__builtins__": {}}, scope)
        
        if isinstance(result, np.ndarray):
            outputs = result
        else:
            outputs = np.array([result] * num_trials)
    except Exception as e:
        logger.error(f"Error evaluating formula: {str(e)}")
        outputs = np.zeros(num_trials)
    
    # Calculate statistics
    percentiles = [1, 5, 10, 25, 50, 75, 90, 95, 99]
    percentile_values = np.percentile(outputs, percentiles)
    
    # Prepare histogram data
    hist, bin_edges = np.histogram(outputs, bins=20, density=True)
    hist_data = [{"bin": float(bin_edges[i]), "frequency": float(hist[i])} for i in range(len(hist))]
    
    # Create results
    results = {
        "summary_statistics": {
            "mean": float(np.mean(outputs)),
            "median": float(np.median(outputs)),
            "std_dev": float(np.std(outputs)),
            "min": float(np.min(outputs)),
            "max": float(np.max(outputs))
        },
        "percentiles": {str(percentiles[i]): float(percentile_values[i]) for i in range(len(percentiles))},
        "histogram": hist_data,
        "num_trials": num_trials
    }
    
    return results

def run_scenario_analysis(parameters):
    """Run a scenario analysis simulation."""
    # Extract base case and scenarios
    scenarios = []
    base_case = {}
    
    for param in parameters:
        if param['name'] == 'base_case' and param['type'] == 'object':
            base_case = param['value']
        elif param['name'] == 'scenarios' and param['type'] == 'array':
            scenarios = param['value']
    
    # If no scenarios provided, create a simple one
    if not scenarios:
        scenarios = [{"name": "Scenario 1", "values": {}}]
    
    # Compute results for each scenario
    results = []
    for scenario in scenarios:
        # Create a copy of base case and override with scenario values
        scenario_values = base_case.copy()
        scenario_values.update(scenario.get('values', {}))
        
        # Compute output
        try:
            output = compute_scenario_output(scenario_values)
        except Exception as e:
            logger.error(f"Error computing scenario output: {str(e)}")
            output = 0
            
        results.append({
            "name": scenario.get('name', 'Unnamed Scenario'),
            "values": scenario_values,
            "output": output
        })
    
    return {
        "base_case": base_case,
        "scenarios": results
    }

def compute_scenario_output(scenario_values):
    """Compute output for a scenario based on its values."""
    # This is a placeholder function that should be customized
    # based on the specific risk model being implemented
    
    # Simple example: sum of all numeric values
    output = sum(v for v in scenario_values.values() if isinstance(v, (int, float)))
    return output

def run_sensitivity_analysis(parameters):
    """Run a sensitivity analysis simulation."""
    # Extract base values and ranges
    base_values = {}
    ranges = {}
    steps = 10  # Default number of steps
    
    for param in parameters:
        if param['name'] == 'base_values' and param['type'] == 'object':
            base_values = param['value']
        elif param['name'] == 'ranges' and param['type'] == 'object':
            ranges = param['value']
        elif param['name'] == 'steps' and param['type'] == 'integer':
            steps = int(param['value'])
    
    results = {}
    
    # For each variable, vary it across its range while keeping others at base
    for var_name, range_spec in ranges.items():
        if var_name in base_values:
            base_value = base_values[var_name]
            min_value = range_spec.get('min', base_value * 0.5)
            max_value = range_spec.get('max', base_value * 1.5)
            
            # Generate values across the range
            if isinstance(base_value, int):
                values = np.linspace(min_value, max_value, steps, dtype=int)
            else:
                values = np.linspace(min_value, max_value, steps)
            
            # Compute output for each value
            outputs = []
            for value in values:
                scenario = base_values.copy()
                scenario[var_name] = float(value)
                
                try:
                    output = compute_scenario_output(scenario)
                except Exception as e:
                    logger.error(f"Error computing sensitivity output: {str(e)}")
                    output = 0
                    
                outputs.append(output)
            
            # Store results
            results[var_name] = {
                "values": [float(v) for v in values],
                "outputs": outputs,
                "base_value": base_value,
                "min_value": min_value,
                "max_value": max_value
            }
    
    return {
        "base_values": base_values,
        "sensitivity_analysis": results
    }

def run_stress_test(parameters):
    """Run a stress test simulation."""
    # Extract parameters
    base_values = {}
    stress_scenarios = []
    
    for param in parameters:
        if param['name'] == 'base_values' and param['type'] == 'object':
            base_values = param['value']
        elif param['name'] == 'stress_scenarios' and param['type'] == 'array':
            stress_scenarios = param['value']
    
    # Compute base case output
    try:
        base_output = compute_scenario_output(base_values)
    except Exception as e:
        logger.error(f"Error computing base output: {str(e)}")
        base_output = 0
    
    # Compute outputs for each stress scenario
    results = []
    for scenario in stress_scenarios:
        scenario_name = scenario.get('name', 'Unnamed Scenario')
        scenario_values = base_values.copy()
        
        # Apply stress factors
        for var_name, factor in scenario.get('factors', {}).items():
            if var_name in scenario_values:
                scenario_values[var_name] = scenario_values[var_name] * factor
        
        # Compute output
        try:
            output = compute_scenario_output(scenario_values)
        except Exception as e:
            logger.error(f"Error computing stress scenario output: {str(e)}")
            output = 0
            
        # Calculate impact
        impact = output - base_output
        impact_percentage = (impact / base_output) * 100 if base_output != 0 else 0
        
        results.append({
            "name": scenario_name,
            "values": scenario_values,
            "output": output,
            "impact": impact,
            "impact_percentage": impact_percentage
        })
    
    return {
        "base_values": base_values,
        "base_output": base_output,
        "stress_scenarios": results
    }
