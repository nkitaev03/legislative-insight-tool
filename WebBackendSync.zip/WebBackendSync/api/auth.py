from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from app import db
from models import User, UserRole, RefreshToken
from schemas import UserSchema, LoginSchema, ChangePasswordSchema, UserUpdateSchema, TokenSchema, RefreshTokenSchema
from utils import generate_access_token, generate_refresh_token, token_required, role_required, verify_refresh_token, revoke_user_tokens
from utils import validate_schema, log_activity
import logging

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
@validate_schema(UserSchema)
def register(validated_data):
    """Register a new user."""
    # Check if username or email already exists
    if User.query.filter_by(username=validated_data['username']).first():
        return jsonify({'message': 'Username already exists'}), 409
    
    if User.query.filter_by(email=validated_data['email']).first():
        return jsonify({'message': 'Email already exists'}), 409
    
    # Create new user
    user = User(
        username=validated_data['username'],
        email=validated_data['email'],
        first_name=validated_data.get('first_name'),
        last_name=validated_data.get('last_name'),
        role=UserRole.VIEWER  # Default role
    )
    user.password = validated_data['password']
    
    # Save to database
    db.session.add(user)
    db.session.commit()
    
    logger.info(f"New user registered: {user.username}")
    
    # Return user data (excluding password)
    user_schema = UserSchema()
    return jsonify({
        'message': 'User registered successfully',
        'user': user_schema.dump(user)
    }), 201

@auth_bp.route('/login', methods=['POST'])
@validate_schema(LoginSchema)
def login(validated_data):
    """Authenticate a user and return JWT tokens."""
    # Find user by username
    user = User.query.filter_by(username=validated_data['username']).first()
    
    # Check if user exists and password is correct
    if not user or not user.verify_password(validated_data['password']):
        return jsonify({'message': 'Invalid username or password'}), 401
    
    # Check if user is active
    if not user.active:
        return jsonify({'message': 'Account is inactive. Please contact an administrator.'}), 401
    
    # Update last login time
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    # Generate tokens
    access_token = generate_access_token(user.id)
    refresh_token = generate_refresh_token(user.id)
    
    logger.info(f"User logged in: {user.username}")
    
    # Create response
    response_data = {
        'access_token': access_token,
        'refresh_token': refresh_token,
        'token_type': 'bearer',
        'expires_in': current_app.config['JWT_ACCESS_TOKEN_EXPIRES'].seconds
    }
    
    return jsonify(response_data), 200

@auth_bp.route('/refresh', methods=['POST'])
@validate_schema(RefreshTokenSchema)
def refresh(validated_data):
    """Refresh the access token using a refresh token."""
    refresh_token = validated_data['refresh_token']
    
    # Verify the refresh token
    user = verify_refresh_token(refresh_token)
    if not user:
        return jsonify({'message': 'Invalid or expired refresh token'}), 401
    
    # Generate a new access token
    access_token = generate_access_token(user.id)
    
    logger.info(f"Access token refreshed for user: {user.username}")
    
    return jsonify({
        'access_token': access_token,
        'token_type': 'bearer',
        'expires_in': current_app.config['JWT_ACCESS_TOKEN_EXPIRES'].seconds
    }), 200

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
    """Logout a user by revoking all refresh tokens."""
    revoke_user_tokens(current_user.id)
    
    logger.info(f"User logged out: {current_user.username}")
    
    return jsonify({'message': 'User logged out successfully'}), 200

@auth_bp.route('/me', methods=['GET'])
@token_required
def get_current_user(current_user):
    """Get the current user's profile."""
    user_schema = UserSchema()
    return jsonify(user_schema.dump(current_user)), 200

@auth_bp.route('/me', methods=['PUT'])
@token_required
@validate_schema(UserUpdateSchema)
@log_activity('update_profile')
def update_profile(current_user, validated_data):
    """Update the current user's profile."""
    # Update fields
    for key, value in validated_data.items():
        if key != 'role':  # Don't allow users to change their own role
            setattr(current_user, key, value)
    
    db.session.commit()
    
    user_schema = UserSchema()
    return jsonify({
        'message': 'Profile updated successfully',
        'user': user_schema.dump(current_user)
    }), 200

@auth_bp.route('/change-password', methods=['POST'])
@token_required
@validate_schema(ChangePasswordSchema)
@log_activity('change_password')
def change_password(current_user, validated_data):
    """Change the current user's password."""
    # Verify current password
    if not current_user.verify_password(validated_data['current_password']):
        return jsonify({'message': 'Current password is incorrect'}), 401
    
    # Update password
    current_user.password = validated_data['new_password']
    
    # Revoke all refresh tokens
    revoke_user_tokens(current_user.id)
    
    db.session.commit()
    
    return jsonify({'message': 'Password changed successfully'}), 200

@auth_bp.route('/users', methods=['GET'])
@token_required
@role_required(UserRole.ADMIN)
def get_users(current_user):
    """Get all users (admin only)."""
    users = User.query.all()
    user_schema = UserSchema(many=True)
    
    return jsonify(user_schema.dump(users)), 200

@auth_bp.route('/users/<int:user_id>', methods=['GET'])
@token_required
@role_required(UserRole.ADMIN)
def get_user(current_user, user_id):
    """Get a specific user (admin only)."""
    user = User.query.get_or_404(user_id)
    user_schema = UserSchema()
    
    return jsonify(user_schema.dump(user)), 200

@auth_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
@role_required(UserRole.ADMIN)
@validate_schema(UserUpdateSchema)
@log_activity('update_user')
def update_user(current_user, user_id, validated_data):
    """Update a specific user (admin only)."""
    user = User.query.get_or_404(user_id)
    
    # Update fields
    for key, value in validated_data.items():
        setattr(user, key, value)
    
    db.session.commit()
    
    user_schema = UserSchema()
    return jsonify({
        'message': 'User updated successfully',
        'user': user_schema.dump(user)
    }), 200

@auth_bp.route('/users/<int:user_id>/activate', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN)
@log_activity('activate_user')
def activate_user(current_user, user_id):
    """Activate a user account (admin only)."""
    user = User.query.get_or_404(user_id)
    
    user.active = True
    db.session.commit()
    
    return jsonify({'message': 'User activated successfully'}), 200

@auth_bp.route('/users/<int:user_id>/deactivate', methods=['POST'])
@token_required
@role_required(UserRole.ADMIN)
@log_activity('deactivate_user')
def deactivate_user(current_user, user_id):
    """Deactivate a user account (admin only)."""
    user = User.query.get_or_404(user_id)
    
    # Prevent deactivating one's own account
    if user.id == current_user.id:
        return jsonify({'message': 'Cannot deactivate your own account'}), 403
    
    user.active = False
    
    # Revoke all refresh tokens
    revoke_user_tokens(user.id)
    
    db.session.commit()
    
    return jsonify({'message': 'User deactivated successfully'}), 200
