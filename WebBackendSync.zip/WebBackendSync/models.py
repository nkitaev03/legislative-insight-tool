from datetime import datetime
from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy import event
import enum
import uuid

# Enums
class RiskStatus(enum.Enum):
    IDENTIFIED = "identified"
    ASSESSED = "assessed"
    CONTROLLED = "controlled"
    MONITORED = "monitored"
    RESOLVED = "resolved"

class RiskSeverity(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class RiskLikelihood(enum.Enum):
    RARE = "rare"
    UNLIKELY = "unlikely"
    POSSIBLE = "possible"
    LIKELY = "likely"
    ALMOST_CERTAIN = "almost_certain"

class UserRole(enum.Enum):
    ADMIN = "admin"
    RISK_MANAGER = "risk_manager"
    ANALYST = "analyst"
    VIEWER = "viewer"

class DocumentStatus(enum.Enum):
    DRAFT = "draft"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    ARCHIVED = "archived"

class NotificationType(enum.Enum):
    RISK_ALERT = "risk_alert"
    COMPLIANCE_UPDATE = "compliance_update" 
    SYSTEM_NOTIFICATION = "system_notification"
    NEWS_ALERT = "news_alert"

# Association tables
risk_category_association = db.Table(
    'risk_category_association',
    db.Column('risk_id', db.Integer, db.ForeignKey('risk.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('risk_category.id'), primary_key=True)
)

risk_tag_association = db.Table(
    'risk_tag_association',
    db.Column('risk_id', db.Integer, db.ForeignKey('risk.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)

document_tag_association = db.Table(
    'document_tag_association',
    db.Column('document_id', db.Integer, db.ForeignKey('document.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)

# Main models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    _password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    role = db.Column(db.Enum(UserRole), default=UserRole.VIEWER, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    risks = db.relationship('Risk', backref='owner', lazy='dynamic')
    comments = db.relationship('Comment', backref='author', lazy='dynamic')
    notifications = db.relationship('Notification', backref='recipient', lazy='dynamic')
    documents = db.relationship('Document', backref='owner', lazy='dynamic')
    
    @hybrid_property
    def password(self):
        raise AttributeError('password is not a readable attribute')
    
    @password.setter
    def password(self, password):
        self._password_hash = generate_password_hash(password)
    
    def verify_password(self, password):
        return check_password_hash(self._password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class RiskCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<RiskCategory {self.name}>'

class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    
    def __repr__(self):
        return f'<Tag {self.name}>'

class Risk(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.Enum(RiskStatus), default=RiskStatus.IDENTIFIED)
    severity = db.Column(db.Enum(RiskSeverity), default=RiskSeverity.MEDIUM)
    likelihood = db.Column(db.Enum(RiskLikelihood), default=RiskLikelihood.POSSIBLE)
    impact_score = db.Column(db.Float, default=0.0)
    risk_score = db.Column(db.Float, default=0.0)
    mitigation_plan = db.Column(db.Text)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    identified_date = db.Column(db.DateTime, default=datetime.utcnow)
    resolution_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    categories = db.relationship('RiskCategory', secondary=risk_category_association, backref=db.backref('risks', lazy='dynamic'))
    tags = db.relationship('Tag', secondary=risk_tag_association, backref=db.backref('risks', lazy='dynamic'))
    comments = db.relationship('Comment', backref='risk', lazy='dynamic', cascade='all, delete-orphan')
    documents = db.relationship('Document', backref='related_risk', lazy='dynamic')
    
    def __repr__(self):
        return f'<Risk {self.title}>'
    
    @property
    def calculate_risk_score(self):
        # Calculate risk score based on severity, likelihood and impact
        severity_map = {
            RiskSeverity.LOW: 1,
            RiskSeverity.MEDIUM: 2,
            RiskSeverity.HIGH: 3,
            RiskSeverity.CRITICAL: 4
        }
        
        likelihood_map = {
            RiskLikelihood.RARE: 1,
            RiskLikelihood.UNLIKELY: 2,
            RiskLikelihood.POSSIBLE: 3,
            RiskLikelihood.LIKELY: 4,
            RiskLikelihood.ALMOST_CERTAIN: 5
        }
        
        sev_score = severity_map.get(self.severity, 2)
        like_score = likelihood_map.get(self.likelihood, 3)
        impact = self.impact_score if self.impact_score else 2.0
        
        return (sev_score * like_score * impact) / 5

@event.listens_for(Risk, 'before_insert')
@event.listens_for(Risk, 'before_update')
def update_risk_score(mapper, connection, target):
    target.risk_score = target.calculate_risk_score

class Legislation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=False)
    jurisdiction = db.Column(db.String(64))
    effective_date = db.Column(db.Date)
    citation = db.Column(db.String(128))
    url = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    documents = db.relationship('Document', backref='related_legislation', lazy='dynamic')
    
    def __repr__(self):
        return f'<Legislation {self.name}>'

class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    content = db.Column(db.Text, nullable=False)
    source = db.Column(db.String(128))
    publication_date = db.Column(db.DateTime, default=datetime.utcnow)
    url = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<News {self.title}>'

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    risk_id = db.Column(db.Integer, db.ForeignKey('risk.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Comment by {self.author.username} on Risk {self.risk_id}>'

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    notification_type = db.Column(db.Enum(NotificationType), default=NotificationType.SYSTEM_NOTIFICATION)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Notification for {self.recipient.username}>'

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    filename = db.Column(db.String(256), nullable=False)
    file_path = db.Column(db.String(512), nullable=False)
    file_size = db.Column(db.Integer)  # Size in bytes
    file_type = db.Column(db.String(64))
    status = db.Column(db.Enum(DocumentStatus), default=DocumentStatus.DRAFT)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    risk_id = db.Column(db.Integer, db.ForeignKey('risk.id'), nullable=True)
    legislation_id = db.Column(db.Integer, db.ForeignKey('legislation.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    tags = db.relationship('Tag', secondary=document_tag_association, backref=db.backref('documents', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Document {self.title}>'

class Simulation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    simulation_type = db.Column(db.String(64), nullable=False)
    parameters = db.Column(db.JSON)
    results = db.Column(db.JSON)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    executed_at = db.Column(db.DateTime)
    execution_time = db.Column(db.Float)  # in seconds
    
    # Relationship with user who created the simulation
    user = db.relationship('User', foreign_keys=[created_by], backref=db.backref('simulations', lazy='dynamic'))
    
    def __repr__(self):
        return f'<Simulation {self.name}>'

class RefreshToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    token = db.Column(db.String(256), nullable=False, unique=True)
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    revoked = db.Column(db.Boolean, default=False)
    
    # Relationship with user
    user = db.relationship('User', backref=db.backref('refresh_tokens', lazy='dynamic'))
    
    def __repr__(self):
        return f'<RefreshToken for User {self.user_id}>'
