# Настройка Nginx для Risk Management API

Если вы разворачиваете API за Nginx, вот пример конфигурации для настройки обратного прокси.

## Пример конфигурации

Создайте новый файл в `/etc/nginx/sites-available/risk-management-api`:

```nginx
server {
    listen 80;
    server_name your-api-domain.com;

    # Перенаправление на HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name your-api-domain.com;

    # SSL настройки
    ssl_certificate /path/to/your/fullchain.pem;
    ssl_certificate_key /path/to/your/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;

    # Таймауты
    client_max_body_size 16M;
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;

    # Настройки логов
    access_log /var/log/nginx/risk-api-access.log;
    error_log /var/log/nginx/risk-api-error.log;

    # Прокси для API
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Статические файлы (если они есть)
    location /static/ {
        alias /path/to/your/app/static/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
    }

    # Загруженные файлы
    location /uploads/ {
        alias /path/to/your/app/uploads/;
        expires -1;
        add_header Cache-Control "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0";
    }
}
```

## Активация конфигурации

После создания файла конфигурации, выполните следующие команды:

```bash
# Создаем символическую ссылку
sudo ln -s /etc/nginx/sites-available/risk-management-api /etc/nginx/sites-enabled/

# Проверяем конфигурацию на ошибки
sudo nginx -t

# Если нет ошибок, перезапускаем Nginx
sudo systemctl restart nginx
```

## HTTPS с Let's Encrypt

Для настройки SSL с помощью Let's Encrypt:

```bash
# Установка Certbot
sudo apt-get update
sudo apt-get install certbot python3-certbot-nginx

# Получение сертификата
sudo certbot --nginx -d your-api-domain.com

# Настройка автоматического обновления
sudo certbot renew --dry-run
```