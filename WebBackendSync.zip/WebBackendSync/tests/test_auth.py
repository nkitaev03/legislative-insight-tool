import pytest
import json
from app import app, db
from models import User, UserRole
from werkzeug.security import generate_password_hash

@pytest.fixture
def client():
    """Create a test client for the app."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

def create_test_user():
    """Create a test user for authentication tests."""
    user = User(
        username='testuser',
        email='test@example.com',
        _password_hash=generate_password_hash('password123'),
        first_name='Test',
        last_name='User',
        role=UserRole.ADMIN,
        active=True
    )
    db.session.add(user)
    db.session.commit()
    return user

def test_register(client):
    """Test user registration."""
    # Test successful registration
    response = client.post('/api/auth/register', json={
        'username': 'newuser',
        'email': 'newuser@example.com',
        'password': 'password123',
        'first_name': 'New',
        'last_name': 'User'
    })
    
    assert response.status_code == 201
    assert b'User registered successfully' in response.data
    
    # Test duplicate username
    response = client.post('/api/auth/register', json={
        'username': 'newuser',
        'email': 'another@example.com',
        'password': 'password123'
    })
    
    assert response.status_code == 409
    assert b'Username already exists' in response.data
    
    # Test duplicate email
    response = client.post('/api/auth/register', json={
        'username': 'anotheruser',
        'email': 'newuser@example.com',
        'password': 'password123'
    })
    
    assert response.status_code == 409
    assert b'Email already exists' in response.data

def test_login(client):
    """Test user login."""
    # Create a test user
    create_test_user()
    
    # Test successful login
    response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'access_token' in data
    assert 'refresh_token' in data
    
    # Test invalid credentials
    response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'wrongpassword'
    })
    
    assert response.status_code == 401
    assert b'Invalid username or password' in response.data

def test_token_refresh(client):
    """Test token refresh."""
    # Create a test user and log in
    create_test_user()
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    login_data = json.loads(login_response.data)
    refresh_token = login_data['refresh_token']
    
    # Test token refresh
    response = client.post('/api/auth/refresh', json={
        'refresh_token': refresh_token
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'access_token' in data
    
    # Test invalid refresh token
    response = client.post('/api/auth/refresh', json={
        'refresh_token': 'invalid-token'
    })
    
    assert response.status_code == 401
    assert b'Invalid or expired refresh token' in response.data

def test_logout(client):
    """Test user logout."""
    # Create a test user and log in
    create_test_user()
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    login_data = json.loads(login_response.data)
    access_token = login_data['access_token']
    
    # Test logout
    response = client.post('/api/auth/logout', headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 200
    assert b'User logged out successfully' in response.data
    
    # Test using the refresh token after logout
    response = client.post('/api/auth/refresh', json={
        'refresh_token': login_data['refresh_token']
    })
    
    assert response.status_code == 401
    assert b'Invalid or expired refresh token' in response.data

def test_get_current_user(client):
    """Test getting current user profile."""
    # Create a test user and log in
    user = create_test_user()
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    login_data = json.loads(login_response.data)
    access_token = login_data['access_token']
    
    # Test getting current user
    response = client.get('/api/auth/me', headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['username'] == 'testuser'
    assert data['email'] == 'test@example.com'
    assert 'password' not in data

def test_update_profile(client):
    """Test updating user profile."""
    # Create a test user and log in
    create_test_user()
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    login_data = json.loads(login_response.data)
    access_token = login_data['access_token']
    
    # Test updating profile
    response = client.put('/api/auth/me', json={
        'first_name': 'Updated',
        'last_name': 'Name'
    }, headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['user']['first_name'] == 'Updated'
    assert data['user']['last_name'] == 'Name'
    
    # Verify changes persisted
    response = client.get('/api/auth/me', headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    data = json.loads(response.data)
    assert data['first_name'] == 'Updated'
    assert data['last_name'] == 'Name'

def test_change_password(client):
    """Test changing password."""
    # Create a test user and log in
    create_test_user()
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'password123'
    })
    login_data = json.loads(login_response.data)
    access_token = login_data['access_token']
    
    # Test changing password
    response = client.post('/api/auth/change-password', json={
        'current_password': 'password123',
        'new_password': 'newpassword123',
        'confirm_password': 'newpassword123'
    }, headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 200
    assert b'Password changed successfully' in response.data
    
    # Test incorrect current password
    response = client.post('/api/auth/change-password', json={
        'current_password': 'wrongpassword',
        'new_password': 'newpassword456',
        'confirm_password': 'newpassword456'
    }, headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 401
    assert b'Current password is incorrect' in response.data
    
    # Test password mismatch
    response = client.post('/api/auth/change-password', json={
        'current_password': 'password123',
        'new_password': 'newpassword123',
        'confirm_password': 'mismatchedpassword'
    }, headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 400
    
    # Verify old token is invalidated
    response = client.get('/api/auth/me', headers={
        'Authorization': f'Bearer {access_token}'
    })
    
    assert response.status_code == 401
    
    # Verify login with new password works
    login_response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'newpassword123'
    })
    
    assert login_response.status_code == 200
