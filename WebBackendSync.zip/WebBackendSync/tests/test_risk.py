import pytest
import json
from app import app, db
from models import User, UserRole, Risk, RiskCategory, Tag, Comment, RiskStatus, RiskSeverity, RiskLikelihood
from werkzeug.security import generate_password_hash

@pytest.fixture
def client():
    """Create a test client for the app."""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

def create_test_user(is_admin=True):
    """Create a test user for risk tests."""
    role = UserRole.ADMIN if is_admin else UserRole.VIEWER
    user = User(
        username='testuser',
        email='test@example.com',
        _password_hash=generate_password_hash('password123'),
        first_name='Test',
        last_name='User',
        role=role,
        active=True
    )
    db.session.add(user)
    db.session.commit()
    return user

def create_test_category():
    """Create a test risk category."""
    category = RiskCategory(
        name='Test Category',
        description='A test category for risks'
    )
    db.session.add(category)
    db.session.commit()
    return category

def create_test_tag():
    """Create a test tag."""
    tag = Tag(name='test-tag')
    db.session.add(tag)
    db.session.commit()
    return tag

def create_test_risk(owner_id, category=None, tags=None):
    """Create a test risk."""
    risk = Risk(
        title='Test Risk',
        description='A test risk description',
        status=RiskStatus.IDENTIFIED,
        severity=RiskSeverity.MEDIUM,
        likelihood=RiskLikelihood.POSSIBLE,
        impact_score=5.0,
        mitigation_plan='Test mitigation plan',
        owner_id=owner_id
    )
    
    if category:
        risk.categories.append(category)
    
    if tags:
        for tag in tags:
            risk.tags.append(tag)
    
    db.session.add(risk)
    db.session.commit()
    return risk

def get_auth_token(client, username='testuser', password='password123'):
    """Get an authentication token for API requests."""
    response = client.post('/api/auth/login', json={
        'username': username,
        'password': password
    })
    return json.loads(response.data)['access_token']

def test_get_risk_categories(client):
    """Test getting risk categories."""
    # Create a test user and category
    create_test_user()
    category = create_test_category()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test getting categories
    response = client.get('/api/risks/categories', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) > 0
    assert any(cat['name'] == category.name for cat in data)

def test_create_risk_category(client):
    """Test creating a risk category."""
    # Create a test user
    create_test_user()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test creating a category
    response = client.post('/api/risks/categories', json={
        'name': 'New Category',
        'description': 'A new risk category'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['category']['name'] == 'New Category'
    
    # Test creating a duplicate category
    response = client.post('/api/risks/categories', json={
        'name': 'New Category',
        'description': 'Duplicate category'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 409
    assert b'Category already exists' in response.data

def test_update_risk_category(client):
    """Test updating a risk category."""
    # Create a test user and category
    create_test_user()
    category = create_test_category()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test updating a category
    response = client.put(f'/api/risks/categories/{category.id}', json={
        'name': 'Updated Category',
        'description': 'Updated description'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['category']['name'] == 'Updated Category'
    assert data['category']['description'] == 'Updated description'

def test_delete_risk_category(client):
    """Test deleting a risk category."""
    # Create a test user and category
    user = create_test_user()
    category = create_test_category()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test deleting a category
    response = client.delete(f'/api/risks/categories/{category.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    assert b'Risk category deleted successfully' in response.data
    
    # Create a category with associated risks and test deletion
    category = create_test_category()
    risk = create_test_risk(owner_id=user.id, category=category)
    
    response = client.delete(f'/api/risks/categories/{category.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 400
    assert b'Cannot delete category that is associated with risks' in response.data

def test_get_tags(client):
    """Test getting tags."""
    # Create a test user and tag
    create_test_user()
    tag = create_test_tag()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test getting tags
    response = client.get('/api/risks/tags', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) > 0
    assert any(t['name'] == tag.name for t in data)

def test_create_tag(client):
    """Test creating a tag."""
    # Create a test user
    create_test_user()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test creating a tag
    response = client.post('/api/risks/tags', json={
        'name': 'new-tag'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['tag']['name'] == 'new-tag'
    
    # Test creating a duplicate tag
    response = client.post('/api/risks/tags', json={
        'name': 'new-tag'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 409
    assert b'Tag already exists' in response.data

def test_update_tag(client):
    """Test updating a tag."""
    # Create a test user and tag
    create_test_user()
    tag = create_test_tag()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test updating a tag
    response = client.put(f'/api/risks/tags/{tag.id}', json={
        'name': 'updated-tag'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['tag']['name'] == 'updated-tag'

def test_delete_tag(client):
    """Test deleting a tag."""
    # Create a test user and tag
    create_test_user()
    tag = create_test_tag()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test deleting a tag
    response = client.delete(f'/api/risks/tags/{tag.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    assert b'Tag deleted successfully' in response.data

def test_get_risks(client):
    """Test getting risks with filters and pagination."""
    # Create a test user and risk
    user = create_test_user()
    category = create_test_category()
    tag = create_test_tag()
    risk = create_test_risk(owner_id=user.id, category=category, tags=[tag])
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test getting all risks
    response = client.get('/api/risks', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data['risks']) > 0
    
    # Test filtering by status
    response = client.get(f'/api/risks?status={risk.status.value}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data['risks']) > 0
    
    # Test filtering by severity
    response = client.get(f'/api/risks?severity={risk.severity.value}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data['risks']) > 0
    
    # Test filtering by category
    response = client.get(f'/api/risks?category_id={category.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data['risks']) > 0
    
    # Test filtering by tag
    response = client.get(f'/api/risks?tag_id={tag.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data['risks']) > 0
    
    # Test pagination
    response = client.get('/api/risks?page=1&per_page=10', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'pagination' in data
    assert data['pagination']['current_page'] == 1
    assert data['pagination']['per_page'] == 10

def test_create_risk(client):
    """Test creating a risk."""
    # Create a test user, category, and tag
    user = create_test_user()
    category = create_test_category()
    tag = create_test_tag()
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test creating a risk
    response = client.post('/api/risks', json={
        'title': 'New Risk',
        'description': 'A new risk description',
        'status': RiskStatus.IDENTIFIED.value,
        'severity': RiskSeverity.HIGH.value,
        'likelihood': RiskLikelihood.LIKELY.value,
        'impact_score': 7.5,
        'mitigation_plan': 'New mitigation plan',
        'owner_id': user.id,
        'categories': [{'id': category.id}],
        'tags': [{'id': tag.id}, {'name': 'new-risk-tag'}]
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['risk']['title'] == 'New Risk'
    assert data['risk']['severity'] == RiskSeverity.HIGH.value
    assert len(data['risk']['categories']) == 1
    assert len(data['risk']['tags']) == 2

def test_get_single_risk(client):
    """Test getting a single risk."""
    # Create a test user and risk
    user = create_test_user()
    risk = create_test_risk(owner_id=user.id)
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test getting a risk
    response = client.get(f'/api/risks/{risk.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['title'] == risk.title
    assert data['description'] == risk.description
    assert data['status'] == risk.status.value
    assert data['severity'] == risk.severity.value
    assert data['likelihood'] == risk.likelihood.value

def test_update_risk(client):
    """Test updating a risk."""
    # Create a test user and risk
    user = create_test_user()
    category = create_test_category()
    risk = create_test_risk(owner_id=user.id)
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test updating a risk
    response = client.put(f'/api/risks/{risk.id}', json={
        'title': 'Updated Risk',
        'description': 'Updated risk description',
        'status': RiskStatus.CONTROLLED.value,
        'severity': RiskSeverity.LOW.value,
        'categories': [{'id': category.id}]
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['risk']['title'] == 'Updated Risk'
    assert data['risk']['description'] == 'Updated risk description'
    assert data['risk']['status'] == RiskStatus.CONTROLLED.value
    assert data['risk']['severity'] == RiskSeverity.LOW.value
    assert len(data['risk']['categories']) == 1
    
    # Test updating as non-owner without admin rights
    non_admin = User(
        username='nonowner',
        email='nonowner@example.com',
        _password_hash=generate_password_hash('password123'),
        role=UserRole.VIEWER,
        active=True
    )
    db.session.add(non_admin)
    db.session.commit()
    
    non_admin_token = get_auth_token(client, 'nonowner', 'password123')
    
    response = client.put(f'/api/risks/{risk.id}', json={
        'title': 'Unauthorized Update'
    }, headers={
        'Authorization': f'Bearer {non_admin_token}'
    })
    
    assert response.status_code == 403
    assert b'You do not have permission to update this risk' in response.data

def test_delete_risk(client):
    """Test deleting a risk."""
    # Create a test user and risk
    user = create_test_user()
    risk = create_test_risk(owner_id=user.id)
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test deleting a risk
    response = client.delete(f'/api/risks/{risk.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    assert b'Risk deleted successfully' in response.data
    
    # Verify the risk is deleted
    response = client.get(f'/api/risks/{risk.id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 404

def test_risk_comments(client):
    """Test risk comments functionality."""
    # Create a test user and risk
    user = create_test_user()
    risk = create_test_risk(owner_id=user.id)
    
    # Get auth token
    token = get_auth_token(client)
    
    # Test adding a comment
    response = client.post(f'/api/risks/{risk.id}/comments', json={
        'content': 'Test comment'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert data['comment']['content'] == 'Test comment'
    assert data['comment']['author_id'] == user.id
    
    comment_id = data['comment']['id']
    
    # Test getting comments
    response = client.get(f'/api/risks/{risk.id}/comments', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert len(data) > 0
    assert any(comment['content'] == 'Test comment' for comment in data)
    
    # Test updating a comment
    response = client.put(f'/api/risks/{risk.id}/comments/{comment_id}', json={
        'content': 'Updated comment'
    }, headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['comment']['content'] == 'Updated comment'
    
    # Test deleting a comment
    response = client.delete(f'/api/risks/{risk.id}/comments/{comment_id}', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    assert b'Comment deleted successfully' in response.data
    
    # Verify the comment is deleted
    response = client.get(f'/api/risks/{risk.id}/comments', headers={
        'Authorization': f'Bearer {token}'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert not any(comment['id'] == comment_id for comment in data)

def test_risk_permissions(client):
    """Test risk permissions for different user roles."""
    # Create admin and non-admin users
    admin = create_test_user(is_admin=True)
    
    non_admin = User(
        username='regular',
        email='regular@example.com',
        _password_hash=generate_password_hash('password123'),
        role=UserRole.VIEWER,
        active=True
    )
    db.session.add(non_admin)
    db.session.commit()
    
    analyst = User(
        username='analyst',
        email='analyst@example.com',
        _password_hash=generate_password_hash('password123'),
        role=UserRole.ANALYST,
        active=True
    )
    db.session.add(analyst)
    db.session.commit()
    
    # Get tokens
    admin_token = get_auth_token(client, 'testuser', 'password123')
    viewer_token = get_auth_token(client, 'regular', 'password123')
    analyst_token = get_auth_token(client, 'analyst', 'password123')
    
    # Test category creation permissions
    response = client.post('/api/risks/categories', json={
        'name': 'Viewer Category',
        'description': 'Created by viewer'
    }, headers={
        'Authorization': f'Bearer {viewer_token}'
    })
    
    assert response.status_code == 403  # Viewers cannot create categories
    
    response = client.post('/api/risks/categories', json={
        'name': 'Analyst Category',
        'description': 'Created by analyst'
    }, headers={
        'Authorization': f'Bearer {analyst_token}'
    })
    
    assert response.status_code == 403  # Analysts cannot create categories
    
    # Test risk creation permissions
    # Viewers cannot create risks
    response = client.post('/api/risks', json={
        'title': 'Viewer Risk',
        'description': 'Risk created by viewer',
        'status': RiskStatus.IDENTIFIED.value,
        'severity': RiskSeverity.MEDIUM.value,
        'likelihood': RiskLikelihood.POSSIBLE.value
    }, headers={
        'Authorization': f'Bearer {viewer_token}'
    })
    
    assert response.status_code == 403
    
    # Analysts can create risks
    response = client.post('/api/risks', json={
        'title': 'Analyst Risk',
        'description': 'Risk created by analyst',
        'status': RiskStatus.IDENTIFIED.value,
        'severity': RiskSeverity.MEDIUM.value,
        'likelihood': RiskLikelihood.POSSIBLE.value
    }, headers={
        'Authorization': f'Bearer {analyst_token}'
    })
    
    assert response.status_code == 201
    analyst_risk_id = json.loads(response.data)['risk']['id']
    
    # Create a risk as admin
    response = client.post('/api/risks', json={
        'title': 'Admin Risk',
        'description': 'Risk created by admin',
        'status': RiskStatus.IDENTIFIED.value,
        'severity': RiskSeverity.HIGH.value,
        'likelihood': RiskLikelihood.LIKELY.value,
        'owner_id': admin.id
    }, headers={
        'Authorization': f'Bearer {admin_token}'
    })
    
    assert response.status_code == 201
    admin_risk_id = json.loads(response.data)['risk']['id']
    
    # Test update permissions
    # Analysts can update their own risks
    response = client.put(f'/api/risks/{analyst_risk_id}', json={
        'title': 'Updated Analyst Risk'
    }, headers={
        'Authorization': f'Bearer {analyst_token}'
    })
    
    assert response.status_code == 200
    
    # Analysts cannot update others' risks
    response = client.put(f'/api/risks/{admin_risk_id}', json={
        'title': 'Unauthorized Update'
    }, headers={
        'Authorization': f'Bearer {analyst_token}'
    })
    
    assert response.status_code == 403
    
    # Admins can update any risk
    response = client.put(f'/api/risks/{analyst_risk_id}', json={
        'title': 'Admin Updated Risk'
    }, headers={
        'Authorization': f'Bearer {admin_token}'
    })
    
    assert response.status_code == 200
    
    # Test delete permissions
    # Analysts cannot delete risks
    response = client.delete(f'/api/risks/{analyst_risk_id}', headers={
        'Authorization': f'Bearer {analyst_token}'
    })
    
    assert response.status_code == 403
    
    # Admins can delete risks
    response = client.delete(f'/api/risks/{analyst_risk_id}', headers={
        'Authorization': f'Bearer {admin_token}'
    })
    
    assert response.status_code == 200
