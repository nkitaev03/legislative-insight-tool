import os
import logging
from datetime import timedelta
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_jwt_extended import JWTManager
from flask_marshmallow import Marshmallow
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS

# Initialize logger
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize database
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Load configuration
app.config.from_pyfile('config.py')

# Database initialization
db.init_app(app)

# Initialize marshmallow for serialization
ma = Marshmallow(app)

# Initialize JWT
jwt = JWTManager(app)

# Configure JWT
app.config['JWT_SECRET_KEY'] = app.config.get('JWT_SECRET_KEY', 'dev-secret-key')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = app.config.get('JWT_ACCESS_TOKEN_EXPIRES', timedelta(hours=1))
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = app.config.get('JWT_REFRESH_TOKEN_EXPIRES', timedelta(days=30))

@jwt.user_identity_loader
def user_identity_lookup(user_id):
    return str(user_id)

@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    from models import User
    identity = jwt_data["sub"]
    return User.query.filter_by(id=int(identity)).one_or_none()

# Initialize CORS
CORS(app)

# Initialize rate limiter
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=[app.config.get('RATE_LIMIT_DEFAULT')],
    storage_uri="memory://",
)

# Create all database tables
with app.app_context():
    # Import models here
    import models
    
    # Handle database creation safely
    try:
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")
        # Try to create tables without recreating enums
        try:
            # Check existing tables
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            existing_tables = inspector.get_table_names()
            logger.info(f"Existing tables: {existing_tables}")
            
            if len(existing_tables) == 0:
                logger.info("No tables exist, creating all from scratch")
                db.create_all()
            else:
                logger.info("Tables already exist, skipping enum creation")
                # You might need to update any new tables or columns
                # This is a simplified approach
        except Exception as inner_e:
            logger.error(f"Error in fallback database creation: {str(inner_e)}")

# Register API blueprints
from api.auth import auth_bp
from api.risk import risk_bp
from api.legislation import legislation_bp
from api.news import news_bp
from api.simulation import simulation_bp
from api.analytics import analytics_bp
from api.notification import notification_bp
from api.document import document_bp
from api.scraper import scraper_bp

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(risk_bp, url_prefix='/api/risks')
app.register_blueprint(legislation_bp, url_prefix='/api/legislation')
app.register_blueprint(news_bp, url_prefix='/api/news')
app.register_blueprint(simulation_bp, url_prefix='/api/simulations')
app.register_blueprint(analytics_bp, url_prefix='/api/analytics')
app.register_blueprint(notification_bp, url_prefix='/api/notifications')
app.register_blueprint(document_bp, url_prefix='/api/documents')
app.register_blueprint(scraper_bp, url_prefix='/api/scraper')

@app.route('/')
def hello():
    return {"message": "Risk Management API is running"}, 200

@app.route('/api/health')
def health_check():
    """
    Endpoint for health check used by monitoring systems.
    """
    try:
        # Проверяем, что база данных работает
        from sqlalchemy import text
        db.session.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}, 200
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {"status": "unhealthy", "database": "disconnected", "error": str(e)}, 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
