from datetime import datetime
from models import News
from app import db
from sqlalchemy import desc, asc, or_, func
import logging

logger = logging.getLogger(__name__)

def get_news_with_filters(
    source=None, 
    published_after=None, 
    published_before=None, 
    search=None, 
    sort_by='publication_date', 
    sort_dir='desc', 
    page=1, 
    per_page=20
):
    """
    Get news items with filtering and pagination.
    
    Args:
        source (str, optional): Filter by news source
        published_after (datetime, optional): Filter by publication date (after)
        published_before (datetime, optional): Filter by publication date (before)
        search (str, optional): Search term for title, content, source
        sort_by (str, optional): Field to sort by
        sort_dir (str, optional): Sort direction ('asc' or 'desc')
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (news_items, pagination) where news_items is a list of News objects and 
               pagination is a dict
    """
    # Start with base query
    query = News.query
    
    # Apply filters
    if source:
        query = query.filter(News.source == source)
        
    if published_after:
        query = query.filter(News.publication_date >= published_after)
        
    if published_before:
        query = query.filter(News.publication_date <= published_before)
        
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                News.title.ilike(search_term),
                News.content.ilike(search_term),
                News.source.ilike(search_term)
            )
        )
    
    # Apply sorting
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(News, sort_by)))
    else:
        query = query.order_by(asc(getattr(News, sort_by)))
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    return pagination.items, pagination_info

def create_news(title, content, source=None, publication_date=None, url=None):
    """
    Create a new news item.
    
    Args:
        title (str): News title
        content (str): News content
        source (str, optional): News source
        publication_date (datetime, optional): Publication date (defaults to now)
        url (str, optional): URL to source
        
    Returns:
        News: Created news object
    """
    if publication_date is None:
        publication_date = datetime.utcnow()
    
    news = News(
        title=title,
        content=content,
        source=source,
        publication_date=publication_date,
        url=url
    )
    
    db.session.add(news)
    db.session.commit()
    
    logger.info(f"News created: {news.title}")
    return news

def update_news(news_id, **kwargs):
    """
    Update an existing news item.
    
    Args:
        news_id (int): News ID
        **kwargs: Fields to update
        
    Returns:
        News: Updated news object
        
    Raises:
        ValueError: If news not found
    """
    news = News.query.get(news_id)
    
    if not news:
        raise ValueError(f"News with ID {news_id} not found")
    
    # Update fields if provided
    for field in ['title', 'content', 'source', 'publication_date', 'url']:
        if field in kwargs:
            setattr(news, field, kwargs[field])
    
    db.session.commit()
    
    logger.info(f"News updated: {news.title}")
    return news

def delete_news(news_id):
    """
    Delete a news item.
    
    Args:
        news_id (int): News ID
        
    Returns:
        bool: True if successful, False if news not found
    """
    news = News.query.get(news_id)
    
    if not news:
        return False
    
    db.session.delete(news)
    db.session.commit()
    
    logger.info(f"News deleted: {news.title}")
    return True

def get_unique_sources():
    """
    Get all unique news sources.
    
    Returns:
        list: List of source strings
    """
    sources = db.session.query(News.source)\
        .filter(News.source.isnot(None))\
        .distinct()\
        .order_by(News.source)\
        .all()
    
    return [s[0] for s in sources if s[0]]
