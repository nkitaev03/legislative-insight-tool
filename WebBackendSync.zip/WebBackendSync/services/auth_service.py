from datetime import datetime
from models import User, RefreshToken, UserRole
from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from utils import generate_access_token, generate_refresh_token
import logging

logger = logging.getLogger(__name__)

def create_user(username, email, password, first_name=None, last_name=None, role=UserRole.VIEWER):
    """
    Create a new user.
    
    Args:
        username (str): Username
        email (str): Email address
        password (str): Password (will be hashed)
        first_name (str, optional): First name
        last_name (str, optional): Last name
        role (UserRole, optional): User role (defaults to VIEWER)
        
    Returns:
        User: The created user object
    
    Raises:
        ValueError: If username or email already exists
    """
    # Check if username or email already exists
    if User.query.filter_by(username=username).first():
        raise ValueError("Username already exists")
    
    if User.query.filter_by(email=email).first():
        raise ValueError("Email already exists")
    
    # Create user
    user = User(
        username=username,
        email=email,
        first_name=first_name,
        last_name=last_name,
        role=role
    )
    
    # Set password (this uses the property setter which hashes the password)
    user.password = password
    
    # Save to database
    db.session.add(user)
    db.session.commit()
    
    logger.info(f"User created: {username}")
    return user

def authenticate_user(username, password):
    """
    Authenticate a user with username and password.
    
    Args:
        username (str): Username
        password (str): Password
        
    Returns:
        tuple: (user, access_token, refresh_token) if successful, None if not
    """
    # Find user
    user = User.query.filter_by(username=username).first()
    
    # Check if user exists and password is correct
    if not user or not user.verify_password(user._password_hash, password):
        return None
    
    # Check if user is active
    if not user.active:
        return None
    
    # Update last login
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    # Generate tokens
    access_token = generate_access_token(user.id)
    refresh_token = generate_refresh_token(user.id)
    
    logger.info(f"User authenticated: {username}")
    return user, access_token, refresh_token

def refresh_user_token(refresh_token_str):
    """
    Refresh a user's access token.
    
    Args:
        refresh_token_str (str): Refresh token string
        
    Returns:
        str or None: New access token if successful, None if not
    """
    # Find refresh token
    token = RefreshToken.query.filter_by(token=refresh_token_str, revoked=False).first()
    
    if not token:
        return None
    
    # Check if token is expired
    if token.expires_at < datetime.utcnow():
        token.revoked = True
        db.session.commit()
        return None
    
    # Get user
    user = User.query.get(token.user_id)
    
    if not user or not user.active:
        return None
    
    # Generate new access token
    return generate_access_token(user.id)

def change_user_password(user, current_password, new_password):
    """
    Change a user's password.
    
    Args:
        user (User): User object
        current_password (str): Current password
        new_password (str): New password
        
    Returns:
        bool: True if successful, False if current password is incorrect
    """
    # Verify current password
    if not user.verify_password(current_password):
        return False
    
    # Update password
    user.password = new_password
    db.session.commit()
    
    logger.info(f"Password changed for user: {user.username}")
    return True

def update_user_profile(user, **kwargs):
    """
    Update a user's profile.
    
    Args:
        user (User): User object
        **kwargs: Fields to update
        
    Returns:
        User: Updated user object
    """
    # Update provided fields
    for key, value in kwargs.items():
        if hasattr(user, key) and key != 'password':
            setattr(user, key, value)
    
    db.session.commit()
    
    logger.info(f"Profile updated for user: {user.username}")
    return user

def get_all_users(active_only=False):
    """
    Get all users.
    
    Args:
        active_only (bool, optional): If True, only return active users
        
    Returns:
        list: List of User objects
    """
    if active_only:
        return User.query.filter_by(active=True).all()
    return User.query.all()

def get_user_by_id(user_id):
    """
    Get a user by ID.
    
    Args:
        user_id (int): User ID
        
    Returns:
        User or None: User object if found, None if not
    """
    return User.query.get(user_id)

def activate_user(user_id):
    """
    Activate a user account.
    
    Args:
        user_id (int): User ID
        
    Returns:
        User or None: User object if found, None if not
    """
    user = User.query.get(user_id)
    
    if not user:
        return None
    
    user.active = True
    db.session.commit()
    
    logger.info(f"User activated: {user.username}")
    return user

def deactivate_user(user_id):
    """
    Deactivate a user account.
    
    Args:
        user_id (int): User ID
        
    Returns:
        User or None: User object if found, None if not
    """
    user = User.query.get(user_id)
    
    if not user:
        return None
    
    user.active = False
    db.session.commit()
    
    logger.info(f"User deactivated: {user.username}")
    return user
