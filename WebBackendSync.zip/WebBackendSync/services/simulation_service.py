import numpy as np
import pandas as pd
from datetime import datetime
import time
from models import Simulation
from app import db
import logging

logger = logging.getLogger(__name__)

def get_simulations_with_filters(
    simulation_type=None, 
    created_by=None, 
    created_after=None, 
    created_before=None, 
    executed=None, 
    sort_by='created_at', 
    sort_dir='desc', 
    page=1, 
    per_page=20
):
    """
    Get simulations with filtering and pagination.
    
    Args:
        simulation_type (str, optional): Filter by simulation type
        created_by (int, optional): Filter by creator ID
        created_after (datetime, optional): Filter by creation date (after)
        created_before (datetime, optional): Filter by creation date (before)
        executed (bool, optional): Filter by execution status
        sort_by (str, optional): Field to sort by
        sort_dir (str, optional): Sort direction ('asc' or 'desc')
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (simulations, pagination) where simulations is a list of Simulation objects 
               and pagination is a dict
    """
    from sqlalchemy import desc, asc
    
    # Start with base query
    query = Simulation.query
    
    # Apply filters
    if simulation_type:
        query = query.filter(Simulation.simulation_type == simulation_type)
        
    if created_by:
        query = query.filter(Simulation.created_by == created_by)
    
    if created_after:
        query = query.filter(Simulation.created_at >= created_after)
        
    if created_before:
        query = query.filter(Simulation.created_at <= created_before)
        
    if executed is not None:
        if executed:
            query = query.filter(Simulation.executed_at.isnot(None))
        else:
            query = query.filter(Simulation.executed_at.is_(None))
    
    # Apply sorting
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Simulation, sort_by)))
    else:
        query = query.order_by(asc(getattr(Simulation, sort_by)))
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    return pagination.items, pagination_info

def create_simulation(name, simulation_type, created_by, description=None, parameters=None):
    """
    Create a new simulation setup.
    
    Args:
        name (str): Simulation name
        simulation_type (str): Type of simulation
        created_by (int): ID of user creating the simulation
        description (str, optional): Description
        parameters (list, optional): List of parameter dictionaries
        
    Returns:
        Simulation: Created simulation object
    """
    simulation = Simulation(
        name=name,
        description=description or '',
        simulation_type=simulation_type,
        parameters=parameters or [],
        created_by=created_by
    )
    
    db.session.add(simulation)
    db.session.commit()
    
    logger.info(f"Simulation created: {simulation.name}")
    return simulation

def update_simulation(simulation_id, **kwargs):
    """
    Update an existing simulation setup.
    
    Args:
        simulation_id (int): Simulation ID
        **kwargs: Fields to update
        
    Returns:
        Simulation: Updated simulation object
        
    Raises:
        ValueError: If simulation not found or already executed
    """
    simulation = Simulation.query.get(simulation_id)
    
    if not simulation:
        raise ValueError(f"Simulation with ID {simulation_id} not found")
    
    # Only allow updates to simulations that haven't been executed yet
    if simulation.executed_at is not None:
        raise ValueError("Cannot update simulation that has already been executed")
    
    # Update fields if provided
    for field in ['name', 'description', 'simulation_type', 'parameters']:
        if field in kwargs:
            setattr(simulation, field, kwargs[field])
    
    db.session.commit()
    
    logger.info(f"Simulation updated: {simulation.name}")
    return simulation

def execute_simulation(simulation_id, custom_parameters=None):
    """
    Execute a simulation.
    
    Args:
        simulation_id (int): Simulation ID
        custom_parameters (list, optional): Custom parameters to override stored ones
        
    Returns:
        Simulation: Updated simulation object with results
        
    Raises:
        ValueError: If simulation not found
        RuntimeError: If error occurs during execution
    """
    simulation = Simulation.query.get(simulation_id)
    
    if not simulation:
        raise ValueError(f"Simulation with ID {simulation_id} not found")
    
    # Use provided parameters or fall back to the stored ones
    parameters = custom_parameters if custom_parameters is not None else simulation.parameters
    
    # Start timer
    start_time = time.time()
    
    try:
        # Execute the simulation based on type
        if simulation.simulation_type == 'monte_carlo':
            results = run_monte_carlo_simulation(parameters)
        elif simulation.simulation_type == 'scenario_analysis':
            results = run_scenario_analysis(parameters)
        elif simulation.simulation_type == 'sensitivity_analysis':
            results = run_sensitivity_analysis(parameters)
        elif simulation.simulation_type == 'stress_test':
            results = run_stress_test(parameters)
        else:
            raise ValueError(f"Unknown simulation type: {simulation.simulation_type}")
        
        # Calculate execution time
        execution_time = time.time() - start_time
        
        # Update simulation with results
        simulation.results = results
        simulation.executed_at = datetime.utcnow()
        simulation.execution_time = execution_time
        
        db.session.commit()
        
        logger.info(f"Simulation executed: {simulation.name} (took {execution_time:.2f}s)")
        return simulation
        
    except Exception as e:
        logger.error(f"Error executing simulation: {str(e)}")
        raise RuntimeError(f"Error executing simulation: {str(e)}")

def run_monte_carlo_simulation(parameters):
    """
    Run a Monte Carlo simulation based on the provided parameters.
    
    Args:
        parameters (list): List of parameter dictionaries
        
    Returns:
        dict: Results of the simulation
    """
    # Extract parameters
    num_trials = 10000  # Default
    for param in parameters:
        if param['name'] == 'num_trials' and param['type'] == 'integer':
            num_trials = int(param['value'])
    
    # Initialize variables for simulation
    variables = {}
    for param in parameters:
        if param['name'].startswith('var_') and param['type'] in ['float', 'integer']:
            var_name = param['name']
            var_type = param.get('distribution', 'normal')
            var_mean = float(param.get('mean', 0))
            var_std = float(param.get('std', 1))
            var_min = float(param.get('min', float('-inf')))
            var_max = float(param.get('max', float('inf')))
            
            # Generate random values based on distribution
            if var_type == 'normal':
                values = np.random.normal(var_mean, var_std, num_trials)
            elif var_type == 'uniform':
                values = np.random.uniform(var_min, var_max, num_trials)
            elif var_type == 'triangular':
                mode = float(param.get('mode', (var_min + var_max) / 2))
                values = np.random.triangular(var_min, mode, var_max, num_trials)
            elif var_type == 'lognormal':
                values = np.random.lognormal(var_mean, var_std, num_trials)
            else:
                values = np.random.normal(var_mean, var_std, num_trials)
                
            # Apply bounds if specified
            if var_min != float('-inf'):
                values = np.maximum(values, var_min)
            if var_max != float('inf'):
                values = np.minimum(values, var_max)
                
            variables[var_name] = values
    
    # If we have a formula parameter, use it to compute the output
    formula = "sum(x)"  # Default formula
    for param in parameters:
        if param['name'] == 'formula' and param['type'] == 'string':
            formula = param['value']
    
    # Convert variables to a DataFrame for easier manipulation
    df = pd.DataFrame(variables)
    
    # Execute formula (safely with limited scope)
    try:
        # Add basic statistical functions to scope
        scope = {
            'df': df,
            'sum': np.sum,
            'min': np.min,
            'max': np.max,
            'mean': np.mean,
            'median': np.median,
            'std': np.std,
            'exp': np.exp,
            'log': np.log,
            'sqrt': np.sqrt
        }
        
        # Add variables to scope
        for var_name, values in variables.items():
            scope[var_name.replace('var_', '')] = values
        
        # Evaluate formula
        result = eval(formula, {"__builtins__": {}}, scope)
        
        if isinstance(result, np.ndarray):
            outputs = result
        else:
            outputs = np.array([result] * num_trials)
    except Exception as e:
        logger.error(f"Error evaluating formula: {str(e)}")
        outputs = np.zeros(num_trials)
    
    # Calculate statistics
    percentiles = [1, 5, 10, 25, 50, 75, 90, 95, 99]
    percentile_values = np.percentile(outputs, percentiles)
    
    # Prepare histogram data
    hist, bin_edges = np.histogram(outputs, bins=20, density=True)
    hist_data = [{"bin": float(bin_edges[i]), "frequency": float(hist[i])} for i in range(len(hist))]
    
    # Create results
    results = {
        "summary_statistics": {
            "mean": float(np.mean(outputs)),
            "median": float(np.median(outputs)),
            "std_dev": float(np.std(outputs)),
            "min": float(np.min(outputs)),
            "max": float(np.max(outputs))
        },
        "percentiles": {str(percentiles[i]): float(percentile_values[i]) for i in range(len(percentiles))},
        "histogram": hist_data,
        "num_trials": num_trials
    }
    
    return results

def run_scenario_analysis(parameters):
    """
    Run a scenario analysis simulation.
    
    Args:
        parameters (list): List of parameter dictionaries
        
    Returns:
        dict: Results of the simulation
    """
    # Extract base case and scenarios
    scenarios = []
    base_case = {}
    
    for param in parameters:
        if param['name'] == 'base_case' and param['type'] == 'object':
            base_case = param['value']
        elif param['name'] == 'scenarios' and param['type'] == 'array':
            scenarios = param['value']
    
    # If no scenarios provided, create a simple one
    if not scenarios:
        scenarios = [{"name": "Scenario 1", "values": {}}]
    
    # Compute results for each scenario
    results = []
    for scenario in scenarios:
        # Create a copy of base case and override with scenario values
        scenario_values = base_case.copy()
        scenario_values.update(scenario.get('values', {}))
        
        # Compute output
        try:
            output = compute_scenario_output(scenario_values)
        except Exception as e:
            logger.error(f"Error computing scenario output: {str(e)}")
            output = 0
            
        results.append({
            "name": scenario.get('name', 'Unnamed Scenario'),
            "values": scenario_values,
            "output": output
        })
    
    return {
        "base_case": base_case,
        "scenarios": results
    }

def compute_scenario_output(scenario_values):
    """
    Compute output for a scenario based on its values.
    
    Args:
        scenario_values (dict): Dictionary of scenario values
        
    Returns:
        float: Computed output
    """
    # This is a placeholder function that should be customized
    # based on the specific risk model being implemented
    
    # Simple example: sum of all numeric values
    output = sum(v for v in scenario_values.values() if isinstance(v, (int, float)))
    return output

def run_sensitivity_analysis(parameters):
    """
    Run a sensitivity analysis simulation.
    
    Args:
        parameters (list): List of parameter dictionaries
        
    Returns:
        dict: Results of the simulation
    """
    # Extract base values and ranges
    base_values = {}
    ranges = {}
    steps = 10  # Default number of steps
    
    for param in parameters:
        if param['name'] == 'base_values' and param['type'] == 'object':
            base_values = param['value']
        elif param['name'] == 'ranges' and param['type'] == 'object':
            ranges = param['value']
        elif param['name'] == 'steps' and param['type'] == 'integer':
            steps = int(param['value'])
    
    results = {}
    
    # For each variable, vary it across its range while keeping others at base
    for var_name, range_spec in ranges.items():
        if var_name in base_values:
            base_value = base_values[var_name]
            min_value = range_spec.get('min', base_value * 0.5)
            max_value = range_spec.get('max', base_value * 1.5)
            
            # Generate values across the range
            if isinstance(base_value, int):
                values = np.linspace(min_value, max_value, steps, dtype=int)
            else:
                values = np.linspace(min_value, max_value, steps)
            
            # Compute output for each value
            outputs = []
            for value in values:
                scenario = base_values.copy()
                scenario[var_name] = float(value)
                
                try:
                    output = compute_scenario_output(scenario)
                except Exception as e:
                    logger.error(f"Error computing sensitivity output: {str(e)}")
                    output = 0
                    
                outputs.append(output)
            
            # Store results
            results[var_name] = {
                "values": [float(v) for v in values],
                "outputs": outputs,
                "base_value": base_value,
                "min_value": min_value,
                "max_value": max_value
            }
    
    return {
        "base_values": base_values,
        "sensitivity_analysis": results
    }

def run_stress_test(parameters):
    """
    Run a stress test simulation.
    
    Args:
        parameters (list): List of parameter dictionaries
        
    Returns:
        dict: Results of the simulation
    """
    # Extract parameters
    base_values = {}
    stress_scenarios = []
    
    for param in parameters:
        if param['name'] == 'base_values' and param['type'] == 'object':
            base_values = param['value']
        elif param['name'] == 'stress_scenarios' and param['type'] == 'array':
            stress_scenarios = param['value']
    
    # Compute base case output
    try:
        base_output = compute_scenario_output(base_values)
    except Exception as e:
        logger.error(f"Error computing base output: {str(e)}")
        base_output = 0
    
    # Compute outputs for each stress scenario
    results = []
    for scenario in stress_scenarios:
        scenario_name = scenario.get('name', 'Unnamed Scenario')
        scenario_values = base_values.copy()
        
        # Apply stress factors
        for var_name, factor in scenario.get('factors', {}).items():
            if var_name in scenario_values:
                scenario_values[var_name] = scenario_values[var_name] * factor
        
        # Compute output
        try:
            output = compute_scenario_output(scenario_values)
        except Exception as e:
            logger.error(f"Error computing stress scenario output: {str(e)}")
            output = 0
            
        # Calculate impact
        impact = output - base_output
        impact_percentage = (impact / base_output) * 100 if base_output != 0 else 0
        
        results.append({
            "name": scenario_name,
            "values": scenario_values,
            "output": output,
            "impact": impact,
            "impact_percentage": impact_percentage
        })
    
    return {
        "base_values": base_values,
        "base_output": base_output,
        "stress_scenarios": results
    }
