from datetime import datetime
from models import Notification, User, NotificationType
from app import db
import logging

logger = logging.getLogger(__name__)

def create_user_notification(recipient_id, message, notification_type=NotificationType.SYSTEM_NOTIFICATION):
    """
    Create a notification for a specific user.
    
    Args:
        recipient_id (int): ID of the recipient user
        message (str): Notification message
        notification_type (NotificationType, optional): Type of notification
        
    Returns:
        Notification: Created notification object
        
    Raises:
        ValueError: If recipient not found
    """
    # Check if recipient exists
    recipient = User.query.get(recipient_id)
    if not recipient:
        raise ValueError(f"User with ID {recipient_id} not found")
    
    # Create notification
    notification = Notification(
        recipient_id=recipient_id,
        message=message,
        notification_type=notification_type,
        is_read=False
    )
    
    db.session.add(notification)
    db.session.commit()
    
    logger.info(f"Notification created for user {recipient_id}")
    return notification

def create_system_notification(recipient_id, message, notification_type=NotificationType.SYSTEM_NOTIFICATION):
    """
    Create a system notification for a user.
    
    Args:
        recipient_id (int): ID of the recipient user
        message (str): Notification message
        notification_type (NotificationType, optional): Type of notification
        
    Returns:
        Notification: Created notification object
    """
    return create_user_notification(
        recipient_id=recipient_id,
        message=message,
        notification_type=notification_type
    )

def create_risk_alert_notification(recipient_id, risk):
    """
    Create a risk alert notification for a user.
    
    Args:
        recipient_id (int): ID of the recipient user
        risk (Risk): Risk object
        
    Returns:
        Notification: Created notification object
    """
    message = f"Risk Alert: {risk.title} - Severity: {risk.severity.value if risk.severity else 'Unknown'}, Score: {risk.risk_score}"
    
    return create_user_notification(
        recipient_id=recipient_id,
        message=message,
        notification_type=NotificationType.RISK_ALERT
    )

def create_compliance_update_notification(recipient_id, legislation):
    """
    Create a compliance update notification for a user.
    
    Args:
        recipient_id (int): ID of the recipient user
        legislation (Legislation): Legislation object
        
    Returns:
        Notification: Created notification object
    """
    message = f"Compliance Update: {legislation.name}"
    
    return create_user_notification(
        recipient_id=recipient_id,
        message=message,
        notification_type=NotificationType.COMPLIANCE_UPDATE
    )

def create_news_alert_notification(recipient_id, news):
    """
    Create a news alert notification for a user.
    
    Args:
        recipient_id (int): ID of the recipient user
        news (News): News object
        
    Returns:
        Notification: Created notification object
    """
    message = f"News Alert: {news.title}"
    
    return create_user_notification(
        recipient_id=recipient_id,
        message=message,
        notification_type=NotificationType.NEWS_ALERT
    )

def get_user_notifications(user_id, is_read=None, notification_type=None, page=1, per_page=20):
    """
    Get notifications for a user with filtering and pagination.
    
    Args:
        user_id (int): User ID
        is_read (bool, optional): Filter by read status
        notification_type (NotificationType, optional): Filter by notification type
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (notifications, pagination) where notifications is a list of Notification objects
               and pagination is a dict
    """
    # Start with base query for user
    query = Notification.query.filter_by(recipient_id=user_id)
    
    # Apply filters
    if is_read is not None:
        query = query.filter(Notification.is_read == is_read)
        
    if notification_type:
        query = query.filter(Notification.notification_type == notification_type)
    
    # Order by creation date (newest first)
    query = query.order_by(Notification.created_at.desc())
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    return pagination.items, pagination_info

def mark_notification_as_read(notification_id):
    """
    Mark a notification as read.
    
    Args:
        notification_id (int): Notification ID
        
    Returns:
        Notification: Updated notification object
        
    Raises:
        ValueError: If notification not found
    """
    notification = Notification.query.get(notification_id)
    
    if not notification:
        raise ValueError(f"Notification with ID {notification_id} not found")
    
    notification.is_read = True
    db.session.commit()
    
    return notification

def mark_all_notifications_as_read(user_id):
    """
    Mark all notifications as read for a user.
    
    Args:
        user_id (int): User ID
        
    Returns:
        int: Number of notifications updated
    """
    count = Notification.query.filter_by(
        recipient_id=user_id, is_read=False
    ).update({'is_read': True})
    
    db.session.commit()
    
    logger.info(f"Marked {count} notifications as read for user {user_id}")
    return count

def get_notification_counts(user_id):
    """
    Get notification counts for a user.
    
    Args:
        user_id (int): User ID
        
    Returns:
        dict: Dict with 'total' and 'unread' counts
    """
    total_count = Notification.query.filter_by(recipient_id=user_id).count()
    unread_count = Notification.query.filter_by(recipient_id=user_id, is_read=False).count()
    
    return {
        'total': total_count,
        'unread': unread_count
    }

def delete_notification(notification_id):
    """
    Delete a notification.
    
    Args:
        notification_id (int): Notification ID
        
    Returns:
        bool: True if successful, False if notification not found
    """
    notification = Notification.query.get(notification_id)
    
    if not notification:
        return False
    
    db.session.delete(notification)
    db.session.commit()
    
    logger.info(f"Notification {notification_id} deleted")
    return True

def create_notification_for_all_users(message, notification_type=NotificationType.SYSTEM_NOTIFICATION):
    """
    Create a notification for all active users in the system.
    
    Args:
        message (str): Notification message
        notification_type (NotificationType, optional): Type of notification
        
    Returns:
        int: Number of notifications created
    """
    # Get all active users
    users = User.query.filter_by(active=True).all()
    count = 0
    
    # Create notification for each user
    for user in users:
        try:
            create_user_notification(
                recipient_id=user.id,
                message=message,
                notification_type=notification_type
            )
            count += 1
        except Exception as e:
            logger.error(f"Failed to create notification for user {user.id}: {str(e)}")
    
    logger.info(f"Created {count} notifications for all users")
    return count
