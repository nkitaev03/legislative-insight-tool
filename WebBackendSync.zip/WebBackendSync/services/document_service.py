import os
from datetime import datetime
from models import Document, Tag, DocumentStatus
from app import db
from sqlalchemy import func
from werkzeug.utils import secure_filename
from utils import save_file, delete_file, allowed_file, get_file_url
import logging

logger = logging.getLogger(__name__)

def create_document(
    title, 
    filename, 
    file_path, 
    owner_id, 
    original_filename=None, 
    description=None, 
    file_size=None, 
    file_type=None, 
    status=DocumentStatus.DRAFT, 
    risk_id=None, 
    legislation_id=None
):
    """
    Create a new document record.
    
    Args:
        title (str): Document title
        filename (str): Stored filename
        file_path (str): File path on server
        owner_id (int): Owner ID
        original_filename (str, optional): Original filename before storage
        description (str, optional): Document description
        file_size (int, optional): File size in bytes
        file_type (str, optional): File type/extension
        status (DocumentStatus, optional): Document status
        risk_id (int, optional): Related risk ID
        legislation_id (int, optional): Related legislation ID
        
    Returns:
        Document: Created document object
    """
    # Create document
    document = Document(
        title=title,
        description=description or '',
        filename=filename,
        file_path=file_path,
        file_size=file_size,
        file_type=file_type,
        status=status,
        owner_id=owner_id,
        risk_id=risk_id,
        legislation_id=legislation_id
    )
    
    db.session.add(document)
    db.session.commit()
    
    logger.info(f"Document created: {document.title}")
    return document

def update_document_metadata(
    document, 
    title=None, 
    description=None, 
    status=None, 
    risk_id=None, 
    legislation_id=None, 
    tags=None
):
    """
    Update document metadata.
    
    Args:
        document (Document): Document object
        title (str, optional): Document title
        description (str, optional): Document description
        status (DocumentStatus, optional): Document status
        risk_id (int, optional): Related risk ID
        legislation_id (int, optional): Related legislation ID
        tags (list, optional): List of tag objects or names
        
    Returns:
        Document: Updated document object
    """
    # Update fields if provided
    if title is not None:
        document.title = title
        
    if description is not None:
        document.description = description
        
    if status is not None:
        document.status = status
        
    if risk_id is not None:
        document.risk_id = risk_id
        
    if legislation_id is not None:
        document.legislation_id = legislation_id
    
    # Update tags if provided
    if tags is not None:
        document.tags = []
        
        for tag_data in tags:
            if isinstance(tag_data, dict) and 'id' in tag_data:
                # If tag has an ID, try to get it from the database
                tag = Tag.query.get(tag_data['id'])
                if tag:
                    document.tags.append(tag)
            elif isinstance(tag_data, dict) and 'name' in tag_data:
                # If tag has a name, find or create it
                tag_name = tag_data['name']
                tag = Tag.query.filter(func.lower(Tag.name) == func.lower(tag_name)).first()
                if not tag:
                    tag = Tag(name=tag_name)
                    db.session.add(tag)
                document.tags.append(tag)
            elif isinstance(tag_data, str):
                # If tag is just a string name
                tag = Tag.query.filter(func.lower(Tag.name) == func.lower(tag_data)).first()
                if not tag:
                    tag = Tag(name=tag_data)
                    db.session.add(tag)
                document.tags.append(tag)
    
    document.updated_at = datetime.utcnow()
    db.session.commit()
    
    logger.info(f"Document updated: {document.title}")
    return document

def get_documents_with_filters(
    status=None, 
    owner_id=None, 
    risk_id=None, 
    legislation_id=None, 
    tag_id=None, 
    file_type=None, 
    created_after=None, 
    created_before=None, 
    search=None, 
    sort_by='created_at', 
    sort_dir='desc', 
    page=1, 
    per_page=20
):
    """
    Get documents with filtering and pagination.
    
    Args:
        status (DocumentStatus, optional): Filter by document status
        owner_id (int, optional): Filter by owner ID
        risk_id (int, optional): Filter by related risk ID
        legislation_id (int, optional): Filter by related legislation ID
        tag_id (int, optional): Filter by tag ID
        file_type (str, optional): Filter by file type
        created_after (datetime, optional): Filter by creation date (after)
        created_before (datetime, optional): Filter by creation date (before)
        search (str, optional): Search term for title, description, filename
        sort_by (str, optional): Field to sort by
        sort_dir (str, optional): Sort direction ('asc' or 'desc')
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (documents, pagination) where documents is a list of Document objects 
               and pagination is a dict
    """
    from sqlalchemy import desc, asc, or_
    
    # Start with base query
    query = Document.query
    
    # Apply filters
    if status:
        query = query.filter(Document.status == status)
        
    if owner_id:
        query = query.filter(Document.owner_id == owner_id)
        
    if risk_id:
        query = query.filter(Document.risk_id == risk_id)
        
    if legislation_id:
        query = query.filter(Document.legislation_id == legislation_id)
        
    if tag_id:
        query = query.join(Document.tags).filter(Tag.id == tag_id)
        
    if file_type:
        query = query.filter(Document.file_type == file_type)
        
    if created_after:
        query = query.filter(Document.created_at >= created_after)
        
    if created_before:
        query = query.filter(Document.created_at <= created_before)
        
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                Document.title.ilike(search_term),
                Document.description.ilike(search_term),
                Document.filename.ilike(search_term)
            )
        )
    
    # Apply sorting
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Document, sort_by)))
    else:
        query = query.order_by(asc(getattr(Document, sort_by)))
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    # Add download URL to each document
    documents = pagination.items
    for doc in documents:
        doc.download_url = get_file_url(doc.file_path, doc.filename)
    
    return documents, pagination_info

def delete_document(document):
    """
    Delete a document and its file.
    
    Args:
        document (Document): Document object
        
    Returns:
        bool: True if successful
        
    Raises:
        Exception: If file deletion fails
    """
    # Delete file from storage
    if not delete_file(document.file_path):
        logger.warning(f"Could not delete file: {document.file_path}")
    
    # Delete from database
    db.session.delete(document)
    db.session.commit()
    
    logger.info(f"Document deleted: {document.title}")
    return True

def get_unique_document_types():
    """
    Get all unique document file types.
    
    Returns:
        list: List of file type strings
    """
    types = db.session.query(Document.file_type)\
        .filter(Document.file_type.isnot(None))\
        .distinct()\
        .order_by(Document.file_type)\
        .all()
    
    return [t[0] for t in types if t[0]]

def get_document_by_filename(filename):
    """
    Get a document by its filename.
    
    Args:
        filename (str): Filename
        
    Returns:
        Document or None: Document object if found, None if not
    """
    return Document.query.filter_by(filename=filename).first()
