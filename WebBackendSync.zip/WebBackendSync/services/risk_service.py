from models import Risk, RiskCategory, Tag, Comment, User, RiskStatus, RiskSeverity, RiskLikelihood
from app import db
from sqlalchemy import desc, asc, func
from utils import send_risk_notification
import logging

logger = logging.getLogger(__name__)

def get_risks_with_filters(
    status=None, 
    severity=None, 
    likelihood=None, 
    owner_id=None, 
    category_id=None, 
    tag_id=None, 
    min_risk_score=None, 
    max_risk_score=None, 
    identified_after=None, 
    identified_before=None, 
    sort_by='created_at', 
    sort_dir='desc', 
    page=1, 
    per_page=20
):
    """
    Get risks with filtering and pagination.
    
    Args:
        status (str, optional): Filter by risk status
        severity (str, optional): Filter by risk severity
        likelihood (str, optional): Filter by risk likelihood
        owner_id (int, optional): Filter by owner ID
        category_id (int, optional): Filter by category ID
        tag_id (int, optional): Filter by tag ID
        min_risk_score (float, optional): Filter by minimum risk score
        max_risk_score (float, optional): Filter by maximum risk score
        identified_after (datetime, optional): Filter by identification date (after)
        identified_before (datetime, optional): Filter by identification date (before)
        sort_by (str, optional): Field to sort by
        sort_dir (str, optional): Sort direction ('asc' or 'desc')
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (risks, pagination) where risks is a list of Risk objects and pagination is a dict
    """
    # Start with base query
    query = Risk.query
    
    # Apply filters
    if status:
        query = query.filter(Risk.status == status)
        
    if severity:
        query = query.filter(Risk.severity == severity)
        
    if likelihood:
        query = query.filter(Risk.likelihood == likelihood)
        
    if owner_id:
        query = query.filter(Risk.owner_id == owner_id)
        
    if category_id:
        query = query.join(Risk.categories).filter(RiskCategory.id == category_id)
        
    if tag_id:
        query = query.join(Risk.tags).filter(Tag.id == tag_id)
        
    if min_risk_score is not None:
        query = query.filter(Risk.risk_score >= min_risk_score)
        
    if max_risk_score is not None:
        query = query.filter(Risk.risk_score <= max_risk_score)
        
    if identified_after:
        query = query.filter(Risk.identified_date >= identified_after)
        
    if identified_before:
        query = query.filter(Risk.identified_date <= identified_before)
    
    # Apply sorting
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Risk, sort_by)))
    else:
        query = query.order_by(asc(getattr(Risk, sort_by)))
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    return pagination.items, pagination_info

def create_risk(
    title, 
    description, 
    status=RiskStatus.IDENTIFIED, 
    severity=RiskSeverity.MEDIUM, 
    likelihood=RiskLikelihood.POSSIBLE, 
    impact_score=0.0, 
    mitigation_plan='', 
    owner_id=None, 
    category_ids=None, 
    tag_names=None, 
    current_user_id=None
):
    """
    Create a new risk.
    
    Args:
        title (str): Risk title
        description (str): Risk description
        status (RiskStatus, optional): Risk status
        severity (RiskSeverity, optional): Risk severity
        likelihood (RiskLikelihood, optional): Risk likelihood
        impact_score (float, optional): Impact score
        mitigation_plan (str, optional): Mitigation plan
        owner_id (int, optional): Owner ID
        category_ids (list, optional): List of category IDs
        tag_names (list, optional): List of tag names
        current_user_id (int, optional): ID of user creating the risk
        
    Returns:
        Risk: Created risk object
    """
    # Create risk
    risk = Risk(
        title=title,
        description=description,
        status=status,
        severity=severity,
        likelihood=likelihood,
        impact_score=impact_score,
        mitigation_plan=mitigation_plan,
        owner_id=owner_id if owner_id else current_user_id
    )
    
    # Add categories
    if category_ids:
        for cat_id in category_ids:
            category = RiskCategory.query.get(cat_id)
            if category:
                risk.categories.append(category)
    
    # Add tags
    if tag_names:
        for tag_name in tag_names:
            tag = Tag.query.filter(func.lower(Tag.name) == func.lower(tag_name)).first()
            if not tag:
                tag = Tag(name=tag_name)
                db.session.add(tag)
            risk.tags.append(tag)
    
    db.session.add(risk)
    db.session.commit()
    
    # Send notification to the owner if different from current user
    if risk.owner_id != current_user_id:
        owner = User.query.get(risk.owner_id)
        if owner:
            send_risk_notification(owner, risk)
    
    logger.info(f"Risk created: {risk.title}")
    return risk

def update_risk(
    risk_id, 
    title=None, 
    description=None, 
    status=None, 
    severity=None, 
    likelihood=None, 
    impact_score=None, 
    mitigation_plan=None, 
    owner_id=None, 
    category_ids=None, 
    tag_names=None, 
    resolution_date=None
):
    """
    Update an existing risk.
    
    Args:
        risk_id (int): Risk ID
        title (str, optional): Risk title
        description (str, optional): Risk description
        status (RiskStatus, optional): Risk status
        severity (RiskSeverity, optional): Risk severity
        likelihood (RiskLikelihood, optional): Risk likelihood
        impact_score (float, optional): Impact score
        mitigation_plan (str, optional): Mitigation plan
        owner_id (int, optional): Owner ID
        category_ids (list, optional): List of category IDs
        tag_names (list, optional): List of tag names
        resolution_date (datetime, optional): Resolution date
        
    Returns:
        Risk: Updated risk object
        
    Raises:
        ValueError: If risk not found
    """
    risk = Risk.query.get(risk_id)
    
    if not risk:
        raise ValueError(f"Risk with ID {risk_id} not found")
    
    # Update fields if provided
    if title is not None:
        risk.title = title
        
    if description is not None:
        risk.description = description
        
    if status is not None:
        risk.status = status
        
    if severity is not None:
        risk.severity = severity
        
    if likelihood is not None:
        risk.likelihood = likelihood
        
    if impact_score is not None:
        risk.impact_score = impact_score
        
    if mitigation_plan is not None:
        risk.mitigation_plan = mitigation_plan
        
    if owner_id is not None:
        risk.owner_id = owner_id
        
    if resolution_date is not None:
        risk.resolution_date = resolution_date
    
    # Update categories if provided
    if category_ids is not None:
        risk.categories = []
        for cat_id in category_ids:
            category = RiskCategory.query.get(cat_id)
            if category:
                risk.categories.append(category)
    
    # Update tags if provided
    if tag_names is not None:
        risk.tags = []
        for tag_name in tag_names:
            tag = Tag.query.filter(func.lower(Tag.name) == func.lower(tag_name)).first()
            if not tag:
                tag = Tag(name=tag_name)
                db.session.add(tag)
            risk.tags.append(tag)
    
    db.session.commit()
    
    logger.info(f"Risk updated: {risk.title}")
    return risk

def delete_risk(risk_id):
    """
    Delete a risk.
    
    Args:
        risk_id (int): Risk ID
        
    Returns:
        bool: True if successful, False if risk not found
    """
    risk = Risk.query.get(risk_id)
    
    if not risk:
        return False
    
    # Delete risk (cascade will handle related entities)
    db.session.delete(risk)
    db.session.commit()
    
    logger.info(f"Risk deleted: {risk.title}")
    return True

def create_risk_category(name, description=''):
    """
    Create a new risk category.
    
    Args:
        name (str): Category name
        description (str, optional): Category description
        
    Returns:
        RiskCategory: Created category object
        
    Raises:
        ValueError: If category with same name already exists
    """
    # Check if category exists
    existing = RiskCategory.query.filter(func.lower(RiskCategory.name) == func.lower(name)).first()
    if existing:
        raise ValueError(f"Category with name '{name}' already exists")
    
    # Create category
    category = RiskCategory(name=name, description=description)
    
    db.session.add(category)
    db.session.commit()
    
    logger.info(f"Risk category created: {category.name}")
    return category

def get_or_create_tag(name):
    """
    Get an existing tag or create a new one.
    
    Args:
        name (str): Tag name
        
    Returns:
        Tag: Tag object
    """
    tag = Tag.query.filter(func.lower(Tag.name) == func.lower(name)).first()
    
    if not tag:
        tag = Tag(name=name)
        db.session.add(tag)
        db.session.commit()
        logger.info(f"Tag created: {tag.name}")
    
    return tag

def add_comment_to_risk(risk_id, content, author_id):
    """
    Add a comment to a risk.
    
    Args:
        risk_id (int): Risk ID
        content (str): Comment content
        author_id (int): Author ID
        
    Returns:
        Comment: Created comment object
        
    Raises:
        ValueError: If risk not found
    """
    risk = Risk.query.get(risk_id)
    
    if not risk:
        raise ValueError(f"Risk with ID {risk_id} not found")
    
    # Create comment
    comment = Comment(
        content=content,
        author_id=author_id,
        risk_id=risk_id
    )
    
    db.session.add(comment)
    db.session.commit()
    
    logger.info(f"Comment added to risk {risk_id} by user {author_id}")
    return comment
