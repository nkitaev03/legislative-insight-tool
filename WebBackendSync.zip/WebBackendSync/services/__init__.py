# This package contains service modules that implement business logic

"""
Services package for the Risk Management Platform.

These service modules encapsulate business logic and keep it separate from the API layer.
Each service module is focused on a specific domain of the application.
"""

