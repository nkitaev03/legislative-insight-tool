from datetime import datetime, timedelta
from sqlalchemy import func, desc, extract, and_
from app import db
from models import Risk, RiskCategory, Tag, User, RiskStatus, RiskSeverity, RiskLikelihood
import logging

logger = logging.getLogger(__name__)

def group_risks_by_attribute(group_by, start_date=None, end_date=None, include_subcategories=False):
    """
    Group risks by a specific attribute with count and average risk score.
    
    Args:
        group_by (str): Attribute to group by ('severity', 'likelihood', 'status', 'category', 'owner', 'tag')
        start_date (datetime, optional): Filter for risks identified after this date
        end_date (datetime, optional): Filter for risks identified before this date
        include_subcategories (bool, optional): Include subcategory breakdown for category grouping
        
    Returns:
        list: List of dicts with group data
        
    Raises:
        ValueError: If invalid group_by value
    """
    # Start with base query
    query = db.session.query(Risk)
    
    # Apply date filters if provided
    if start_date:
        query = query.filter(Risk.identified_date >= start_date)
    if end_date:
        query = query.filter(Risk.identified_date <= end_date)
    
    # Group by the specified attribute
    if group_by == 'severity':
        # Group by severity
        groups = query.with_entities(
            Risk.severity,
            func.count(Risk.id).label('count'),
            func.avg(Risk.risk_score).label('avg_risk_score')
        ).group_by(Risk.severity).all()
        
        return [
            {
                'name': g.severity.value if g.severity else 'Unspecified',
                'count': g.count,
                'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
            }
            for g in groups
        ]
        
    elif group_by == 'likelihood':
        # Group by likelihood
        groups = query.with_entities(
            Risk.likelihood,
            func.count(Risk.id).label('count'),
            func.avg(Risk.risk_score).label('avg_risk_score')
        ).group_by(Risk.likelihood).all()
        
        return [
            {
                'name': g.likelihood.value if g.likelihood else 'Unspecified',
                'count': g.count,
                'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
            }
            for g in groups
        ]
        
    elif group_by == 'status':
        # Group by status
        groups = query.with_entities(
            Risk.status,
            func.count(Risk.id).label('count'),
            func.avg(Risk.risk_score).label('avg_risk_score')
        ).group_by(Risk.status).all()
        
        return [
            {
                'name': g.status.value if g.status else 'Unspecified',
                'count': g.count,
                'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
            }
            for g in groups
        ]
        
    elif group_by == 'category':
        # Group by category
        results = []
        
        if include_subcategories:
            # Get all categories
            categories = RiskCategory.query.all()
            
            for category in categories:
                # Get risks in this category
                category_risks = query.join(Risk.categories).filter(RiskCategory.id == category.id)
                count = category_risks.count()
                
                if count > 0:
                    avg_score = category_risks.with_entities(func.avg(Risk.risk_score)).scalar() or 0
                    
                    # Group by severity within category
                    severity_breakdown = category_risks.with_entities(
                        Risk.severity,
                        func.count(Risk.id).label('count')
                    ).group_by(Risk.severity).all()
                    
                    severity_data = [
                        {'name': s.severity.value if s.severity else 'Unspecified', 'count': s.count}
                        for s in severity_breakdown
                    ]
                    
                    results.append({
                        'name': category.name,
                        'count': count,
                        'avg_risk_score': float(avg_score),
                        'breakdown': {
                            'severity': severity_data
                        }
                    })
            
        else:
            # Simple grouping by category
            groups = db.session.query(
                RiskCategory.name,
                func.count(Risk.id).label('count'),
                func.avg(Risk.risk_score).label('avg_risk_score')
            ).join(Risk.categories).group_by(RiskCategory.name).all()
            
            results = [
                {
                    'name': g.name,
                    'count': g.count,
                    'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
                }
                for g in groups
            ]
            
            # Add uncategorized risks if any
            uncategorized = query.outerjoin(Risk.categories).filter(RiskCategory.id.is_(None))
            uncategorized_count = uncategorized.count()
            
            if uncategorized_count > 0:
                avg_score = uncategorized.with_entities(func.avg(Risk.risk_score)).scalar() or 0
                results.append({
                    'name': 'Uncategorized',
                    'count': uncategorized_count,
                    'avg_risk_score': float(avg_score)
                })
        
        return results
        
    elif group_by == 'owner':
        # Group by owner
        groups = db.session.query(
            User.username,
            func.count(Risk.id).label('count'),
            func.avg(Risk.risk_score).label('avg_risk_score')
        ).join(User, Risk.owner_id == User.id).group_by(User.username).all()
        
        results = [
            {
                'name': g.username,
                'count': g.count,
                'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
            }
            for g in groups
        ]
        
        # Add unassigned risks if any
        unassigned = query.filter(Risk.owner_id.is_(None))
        unassigned_count = unassigned.count()
        
        if unassigned_count > 0:
            avg_score = unassigned.with_entities(func.avg(Risk.risk_score)).scalar() or 0
            results.append({
                'name': 'Unassigned',
                'count': unassigned_count,
                'avg_risk_score': float(avg_score)
            })
            
        return results
        
    elif group_by == 'tag':
        # Group by tag
        groups = db.session.query(
            Tag.name,
            func.count(Risk.id).label('count'),
            func.avg(Risk.risk_score).label('avg_risk_score')
        ).join(Risk.tags).group_by(Tag.name).all()
        
        results = [
            {
                'name': g.name,
                'count': g.count,
                'avg_risk_score': float(g.avg_risk_score) if g.avg_risk_score else 0
            }
            for g in groups
        ]
        
        # Add untagged risks if any
        untagged = query.outerjoin(Risk.tags).filter(Tag.id.is_(None))
        untagged_count = untagged.count()
        
        if untagged_count > 0:
            avg_score = untagged.with_entities(func.avg(Risk.risk_score)).scalar() or 0
            results.append({
                'name': 'Untagged',
                'count': untagged_count,
                'avg_risk_score': float(avg_score)
            })
            
        return results
        
    else:
        raise ValueError(f"Invalid group_by value: {group_by}")

def calculate_risk_trends(time_period, metric, category_id=None, status=None, start_date=None, end_date=None):
    """
    Calculate risk trends over time.
    
    Args:
        time_period (str): Time period to group by ('day', 'week', 'month', 'quarter', 'year')
        metric (str): Metric to track ('count', 'risk_score', 'severity', 'likelihood')
        category_id (int, optional): Filter by category ID
        status (str, optional): Filter by risk status
        start_date (datetime, optional): Start date for trend data
        end_date (datetime, optional): End date for trend data
        
    Returns:
        dict: Trend data with time periods and values
        
    Raises:
        ValueError: If invalid time_period or metric
    """
    # Start with base query
    query = db.session.query(Risk)
    
    # Apply filters
    if category_id:
        query = query.join(Risk.categories).filter(RiskCategory.id == category_id)
        
    if status:
        query = query.filter(Risk.status == status)
    
    # Set default time range if not provided
    if not end_date:
        end_date = datetime.utcnow()
        
    if not start_date:
        # Default to last year
        if time_period == 'day':
            start_date = end_date - timedelta(days=30)  # Last 30 days
        elif time_period == 'week':
            start_date = end_date - timedelta(weeks=12)  # Last 12 weeks
        else:
            start_date = end_date - timedelta(days=365)  # Last year
    
    query = query.filter(Risk.created_at >= start_date, Risk.created_at <= end_date)
    
    # Group by time period
    if time_period == 'day':
        # Group by day
        time_extract = func.date(Risk.created_at)
    elif time_period == 'week':
        # Group by week
        time_extract = func.date_trunc('week', Risk.created_at)
    elif time_period == 'month':
        # Group by month
        time_extract = func.date_trunc('month', Risk.created_at)
    elif time_period == 'quarter':
        # Group by quarter
        time_extract = func.date_trunc('quarter', Risk.created_at)
    elif time_period == 'year':
        # Group by year
        time_extract = func.date_trunc('year', Risk.created_at)
    else:
        raise ValueError(f"Invalid time_period: {time_period}")
    
    # Calculate metric
    if metric == 'count':
        # Count of risks
        groups = query.with_entities(
            time_extract.label('period'),
            func.count(Risk.id).label('value')
        ).group_by('period').order_by('period').all()
        
        return {
            'labels': [str(g.period) for g in groups],
            'values': [g.value for g in groups],
            'metric': 'Risk Count'
        }
        
    elif metric == 'risk_score':
        # Average risk score
        groups = query.with_entities(
            time_extract.label('period'),
            func.avg(Risk.risk_score).label('value')
        ).group_by('period').order_by('period').all()
        
        return {
            'labels': [str(g.period) for g in groups],
            'values': [float(g.value) if g.value else 0 for g in groups],
            'metric': 'Average Risk Score'
        }
        
    elif metric == 'severity':
        # Distribution of severity
        severities = [s.value for s in RiskSeverity]
        result = {'labels': [], 'datasets': []}
        
        for severity in severities:
            result['datasets'].append({
                'label': severity,
                'data': []
            })
        
        # Get time periods
        periods = query.with_entities(
            time_extract.label('period')
        ).group_by('period').order_by('period').all()
        
        # Get data for each period
        for period in periods:
            result['labels'].append(str(period.period))
            
            # Get severity distribution for this period
            severity_counts = query.filter(
                time_extract == period.period
            ).with_entities(
                Risk.severity,
                func.count(Risk.id).label('count')
            ).group_by(Risk.severity).all()
            
            # Create a dict for easy lookup
            severity_dict = {s.severity.value if s.severity else 'None': s.count for s in severity_counts}
            
            # Add values to datasets
            for i, severity in enumerate(severities):
                result['datasets'][i]['data'].append(severity_dict.get(severity, 0))
        
        return result
        
    elif metric == 'likelihood':
        # Distribution of likelihood
        likelihoods = [l.value for l in RiskLikelihood]
        result = {'labels': [], 'datasets': []}
        
        for likelihood in likelihoods:
            result['datasets'].append({
                'label': likelihood,
                'data': []
            })
        
        # Get time periods
        periods = query.with_entities(
            time_extract.label('period')
        ).group_by('period').order_by('period').all()
        
        # Get data for each period
        for period in periods:
            result['labels'].append(str(period.period))
            
            # Get likelihood distribution for this period
            likelihood_counts = query.filter(
                time_extract == period.period
            ).with_entities(
                Risk.likelihood,
                func.count(Risk.id).label('count')
            ).group_by(Risk.likelihood).all()
            
            # Create a dict for easy lookup
            likelihood_dict = {l.likelihood.value if l.likelihood else 'None': l.count for l in likelihood_counts}
            
            # Add values to datasets
            for i, likelihood in enumerate(likelihoods):
                result['datasets'][i]['data'].append(likelihood_dict.get(likelihood, 0))
        
        return result
        
    else:
        raise ValueError(f"Invalid metric: {metric}")

def generate_risk_heatmap(x_axis, y_axis, filter_category=None, filter_status=None):
    """
    Generate data for a risk heatmap visualization.
    
    Args:
        x_axis (str): X-axis attribute ('likelihood', 'impact', 'severity')
        y_axis (str): Y-axis attribute ('likelihood', 'impact', 'severity')
        filter_category (int, optional): Filter by category ID
        filter_status (str, optional): Filter by risk status
        
    Returns:
        dict: Heatmap data with axes and risk counts
        
    Raises:
        ValueError: If invalid axis value or same attribute for both axes
    """
    if x_axis == y_axis:
        raise ValueError("X and Y axes must be different attributes")
    
    # Validate axes
    valid_axes = ['likelihood', 'impact', 'severity']
    if x_axis not in valid_axes or y_axis not in valid_axes:
        raise ValueError(f"Invalid axis value. Must be one of: {', '.join(valid_axes)}")
    
    # Start with base query
    query = db.session.query(Risk)
    
    # Apply filters
    if filter_category:
        query = query.join(Risk.categories).filter(RiskCategory.id == filter_category)
        
    if filter_status:
        query = query.filter(Risk.status == filter_status)
    
    # Define how to get values for each axis type
    def get_axis_values(axis_type):
        if axis_type == 'likelihood':
            return [l.value for l in RiskLikelihood]
        elif axis_type == 'severity':
            return [s.value for s in RiskSeverity]
        elif axis_type == 'impact':
            # For impact, create ranges from 0 to 10
            return ['0-2', '2-4', '4-6', '6-8', '8-10']
    
    # Define how to map a risk to a cell for each axis type
    def map_risk_to_cell(risk, axis_type):
        if axis_type == 'likelihood':
            return risk.likelihood.value if risk.likelihood else 'unknown'
        elif axis_type == 'severity':
            return risk.severity.value if risk.severity else 'unknown'
        elif axis_type == 'impact':
            impact = risk.impact_score or 0
            if impact < 2:
                return '0-2'
            elif impact < 4:
                return '2-4'
            elif impact < 6:
                return '4-6'
            elif impact < 8:
                return '6-8'
            else:
                return '8-10'
    
    # Get axis values
    x_values = get_axis_values(x_axis)
    y_values = get_axis_values(y_axis)
    
    # Initialize heatmap grid
    grid = {y_val: {x_val: [] for x_val in x_values} for y_val in y_values}
    
    # Place risks in the grid
    for risk in query.all():
        x_cell = map_risk_to_cell(risk, x_axis)
        y_cell = map_risk_to_cell(risk, y_axis)
        
        # Skip risks with unknown values
        if x_cell == 'unknown' or y_cell == 'unknown':
            continue
            
        # Skip if cell doesn't exist (e.g., from older data with different enum values)
        if y_cell in grid and x_cell in grid[y_cell]:
            grid[y_cell][x_cell].append({
                'id': risk.id,
                'title': risk.title,
                'risk_score': risk.risk_score
            })
    
    # Convert to format suitable for heatmap visualization
    cells = []
    for y_idx, y_val in enumerate(y_values):
        for x_idx, x_val in enumerate(x_values):
            risks = grid[y_val][x_val]
            cells.append({
                'x': x_idx,
                'y': y_idx,
                'x_value': x_val,
                'y_value': y_val,
                'value': len(risks),
                'risks': risks
            })
    
    return {
        'x_axis': {
            'name': x_axis,
            'values': x_values
        },
        'y_axis': {
            'name': y_axis,
            'values': y_values
        },
        'cells': cells
    }

def get_top_risks(limit=10, metric='risk_score', category_id=None):
    """
    Get top risks based on selected criteria.
    
    Args:
        limit (int, optional): Number of risks to return (default 10)
        metric (str, optional): Metric to sort by ('risk_score', 'impact', 'recent')
        category_id (int, optional): Filter by category ID
        
    Returns:
        list: List of top risks with key attributes
    """
    # Start with base query
    query = db.session.query(Risk)
    
    # Apply category filter if provided
    if category_id:
        query = query.join(Risk.categories).filter(RiskCategory.id == category_id)
    
    # Apply ordering based on metric
    if metric == 'risk_score':
        query = query.order_by(desc(Risk.risk_score))
    elif metric == 'impact':
        query = query.order_by(desc(Risk.impact_score))
    elif metric == 'recent':
        query = query.order_by(desc(Risk.created_at))
    else:
        # Default to risk_score
        query = query.order_by(desc(Risk.risk_score))
    
    # Get limited number of risks
    risks = query.limit(limit).all()
    
    # Format for response
    result = []
    for risk in risks:
        result.append({
            'id': risk.id,
            'title': risk.title,
            'status': risk.status.value if risk.status else None,
            'severity': risk.severity.value if risk.severity else None,
            'likelihood': risk.likelihood.value if risk.likelihood else None,
            'impact_score': risk.impact_score,
            'risk_score': risk.risk_score,
            'created_at': risk.created_at.isoformat() if risk.created_at else None,
            'owner': risk.owner.username if risk.owner else None,
            'categories': [cat.name for cat in risk.categories],
            'tags': [tag.name for tag in risk.tags]
        })
    
    return result
