from models import Legislation
from app import db
from sqlalchemy import desc, asc, or_, func
import logging

logger = logging.getLogger(__name__)

def get_legislation_with_filters(
    jurisdiction=None, 
    effective_after=None, 
    effective_before=None, 
    search=None, 
    sort_by='created_at', 
    sort_dir='desc', 
    page=1, 
    per_page=20
):
    """
    Get legislation with filtering and pagination.
    
    Args:
        jurisdiction (str, optional): Filter by jurisdiction
        effective_after (date, optional): Filter by effective date (after)
        effective_before (date, optional): Filter by effective date (before)
        search (str, optional): Search term for name, description, citation
        sort_by (str, optional): Field to sort by
        sort_dir (str, optional): Sort direction ('asc' or 'desc')
        page (int, optional): Page number
        per_page (int, optional): Items per page
        
    Returns:
        tuple: (legislation, pagination) where legislation is a list of Legislation objects 
               and pagination is a dict
    """
    # Start with base query
    query = Legislation.query
    
    # Apply filters
    if jurisdiction:
        query = query.filter(Legislation.jurisdiction == jurisdiction)
        
    if effective_after:
        query = query.filter(Legislation.effective_date >= effective_after)
        
    if effective_before:
        query = query.filter(Legislation.effective_date <= effective_before)
        
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                Legislation.name.ilike(search_term),
                Legislation.description.ilike(search_term),
                Legislation.citation.ilike(search_term)
            )
        )
    
    # Apply sorting
    if sort_dir == 'desc':
        query = query.order_by(desc(getattr(Legislation, sort_by)))
    else:
        query = query.order_by(asc(getattr(Legislation, sort_by)))
    
    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Create pagination info dict
    pagination_info = {
        'total_items': pagination.total,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'per_page': pagination.per_page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    }
    
    return pagination.items, pagination_info

def create_legislation(name, description, jurisdiction=None, effective_date=None, citation=None, url=None):
    """
    Create a new legislation entry.
    
    Args:
        name (str): Legislation name
        description (str): Legislation description
        jurisdiction (str, optional): Jurisdiction
        effective_date (date, optional): Effective date
        citation (str, optional): Citation
        url (str, optional): URL to official document
        
    Returns:
        Legislation: Created legislation object
    """
    legislation = Legislation(
        name=name,
        description=description,
        jurisdiction=jurisdiction,
        effective_date=effective_date,
        citation=citation,
        url=url
    )
    
    db.session.add(legislation)
    db.session.commit()
    
    logger.info(f"Legislation created: {legislation.name}")
    return legislation

def update_legislation(legislation_id, **kwargs):
    """
    Update an existing legislation entry.
    
    Args:
        legislation_id (int): Legislation ID
        **kwargs: Fields to update
        
    Returns:
        Legislation: Updated legislation object
        
    Raises:
        ValueError: If legislation not found
    """
    legislation = Legislation.query.get(legislation_id)
    
    if not legislation:
        raise ValueError(f"Legislation with ID {legislation_id} not found")
    
    # Update fields if provided
    for field in ['name', 'description', 'jurisdiction', 'effective_date', 'citation', 'url']:
        if field in kwargs:
            setattr(legislation, field, kwargs[field])
    
    db.session.commit()
    
    logger.info(f"Legislation updated: {legislation.name}")
    return legislation

def delete_legislation(legislation_id):
    """
    Delete a legislation entry.
    
    Args:
        legislation_id (int): Legislation ID
        
    Returns:
        bool: True if successful, False if legislation not found
        
    Raises:
        ValueError: If legislation has associated documents
    """
    legislation = Legislation.query.get(legislation_id)
    
    if not legislation:
        return False
    
    # Check if legislation has associated documents
    if legislation.documents.count() > 0:
        raise ValueError(
            f"Cannot delete legislation that has associated documents ({legislation.documents.count()})"
        )
    
    db.session.delete(legislation)
    db.session.commit()
    
    logger.info(f"Legislation deleted: {legislation.name}")
    return True

def get_unique_jurisdictions():
    """
    Get all unique jurisdictions.
    
    Returns:
        list: List of jurisdiction strings
    """
    jurisdictions = db.session.query(Legislation.jurisdiction)\
        .filter(Legislation.jurisdiction.isnot(None))\
        .distinct()\
        .order_by(Legislation.jurisdiction)\
        .all()
    
    return [j[0] for j in jurisdictions if j[0]]
