import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import app, db
from models import User, UserRole

def update_user_role(username, role_name):
    """
    Update a user's role.
    
    Args:
        username (str): Username of the user
        role_name (str): Role name (admin, risk_manager, analyst, viewer)
    """
    with app.app_context():
        user = User.query.filter_by(username=username).first()
        if not user:
            print(f"User {username} not found")
            return
        
        role_map = {
            'admin': UserRole.ADMIN,
            'risk_manager': UserRole.RISK_MANAGER,
            'analyst': UserRole.ANALYST,
            'viewer': UserRole.VIEWER
        }
        
        if role_name.lower() not in role_map:
            print(f"Invalid role: {role_name}")
            print(f"Valid roles: {list(role_map.keys())}")
            return
        
        user.role = role_map[role_name.lower()]
        db.session.commit()
        print(f"Updated {username}'s role to {role_name}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python update_user_role.py <username> <role>")
        sys.exit(1)
    
    username = sys.argv[1]
    role = sys.argv[2]
    update_user_role(username, role)