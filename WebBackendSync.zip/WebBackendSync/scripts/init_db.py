#!/usr/bin/env python3
"""
Database initialization script.
This script creates initial database tables and adds a default admin user.
"""

import sys
import os
import logging
from pathlib import Path

# Add the parent directory to the path so we can import modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from app import app, db
from models import User, UserRole

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def initialize_database():
    """Initialize the database with tables and a default admin user."""
    with app.app_context():
        # Create all tables
        db.create_all()
        logger.info("Database tables created.")

        # Check if admin user exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            # Create default admin user
            admin_password = os.environ.get('ADMIN_PASSWORD', 'adminpassword')
            admin = User(
                username='admin',
                email='admin@example.com',
                first_name='Admin',
                last_name='User',
                role=UserRole.ADMIN,
                active=True
            )
            admin.password = admin_password
            db.session.add(admin)
            db.session.commit()
            logger.info("Default admin user created.")
        else:
            logger.info("Admin user already exists.")

if __name__ == '__main__':
    initialize_database()