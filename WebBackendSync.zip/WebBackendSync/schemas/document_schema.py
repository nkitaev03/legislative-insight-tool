from marshmallow import Schema, fields, validate
from models import DocumentStatus

class DocumentSchema(Schema):
    id = fields.Integer(dump_only=True)
    title = fields.String(required=True, validate=validate.Length(min=3, max=128))
    description = fields.String()
    filename = fields.String(dump_only=True)
    file_path = fields.String(dump_only=True)
    file_size = fields.Integer(dump_only=True)
    file_type = fields.String(dump_only=True)
    status = fields.String(validate=validate.OneOf([status.value for status in DocumentStatus]))
    owner_id = fields.Integer()
    risk_id = fields.Integer(allow_none=True)
    legislation_id = fields.Integer(allow_none=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
    
    tags = fields.List(fields.Nested('TagSchema'))
    owner = fields.Nested('UserSchema', only=('id', 'username'), dump_only=True)
    related_risk = fields.Nested('RiskSchema', only=('id', 'title'), dump_only=True)
    related_legislation = fields.Nested('LegislationSchema', only=('id', 'name'), dump_only=True)

class DocumentQuerySchema(Schema):
    status = fields.String(validate=validate.OneOf([status.value for status in DocumentStatus]))
    owner_id = fields.Integer()
    risk_id = fields.Integer()
    legislation_id = fields.Integer()
    tag_id = fields.Integer()
    file_type = fields.String()
    created_after = fields.DateTime()
    created_before = fields.DateTime()
    search = fields.String()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['title', 'created_at', 'updated_at', 'file_size']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))

class DocumentUpdateSchema(Schema):
    title = fields.String(validate=validate.Length(min=3, max=128))
    description = fields.String()
    status = fields.String(validate=validate.OneOf([status.value for status in DocumentStatus]))
    risk_id = fields.Integer(allow_none=True)
    legislation_id = fields.Integer(allow_none=True)
    tags = fields.List(fields.Nested('TagSchema', only=('id', 'name')))
