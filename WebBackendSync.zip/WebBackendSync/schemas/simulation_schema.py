from marshmallow import Schema, fields, validate, validates, ValidationError

class SimulationParameterSchema(Schema):
    name = fields.String(required=True)
    type = fields.String(required=True, validate=validate.OneOf(['float', 'integer', 'boolean', 'string', 'array']))
    value = fields.Raw(required=True)
    min = fields.Float(allow_none=True)
    max = fields.Float(allow_none=True)
    step = fields.Float(allow_none=True)
    options = fields.List(fields.Raw(), allow_none=True)
    
    @validates('value')
    def validate_value(self, value, **kwargs):
        data = kwargs.get('data', {})
        param_type = data.get('type')
        
        if param_type == 'float':
            try:
                float(value)
            except (ValueError, TypeError):
                raise ValidationError('Value must be a float')
                
            # Check min/max bounds
            if 'min' in data and data['min'] is not None and float(value) < data['min']:
                raise ValidationError(f'Value must be greater than or equal to {data["min"]}')
            if 'max' in data and data['max'] is not None and float(value) > data['max']:
                raise ValidationError(f'Value must be less than or equal to {data["max"]}')
                
        elif param_type == 'integer':
            try:
                if not isinstance(value, int) and not float(value).is_integer():
                    raise ValidationError('Value must be an integer')
            except (ValueError, TypeError):
                raise ValidationError('Value must be an integer')
                
            # Check min/max bounds
            if 'min' in data and data['min'] is not None and int(value) < data['min']:
                raise ValidationError(f'Value must be greater than or equal to {data["min"]}')
            if 'max' in data and data['max'] is not None and int(value) > data['max']:
                raise ValidationError(f'Value must be less than or equal to {data["max"]}')
                
        elif param_type == 'boolean' and not isinstance(value, bool):
            raise ValidationError('Value must be a boolean')
            
        elif param_type == 'string' and not isinstance(value, str):
            raise ValidationError('Value must be a string')
            
        elif param_type == 'array' and not isinstance(value, list):
            raise ValidationError('Value must be an array')
            
        # Check if value is in options
        if 'options' in data and data['options'] and value not in data['options']:
            raise ValidationError(f'Value must be one of: {", ".join(str(o) for o in data["options"])}')

class SimulationSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True, validate=validate.Length(min=3, max=128))
    description = fields.String()
    simulation_type = fields.String(required=True, validate=validate.OneOf(['monte_carlo', 'scenario_analysis', 'sensitivity_analysis', 'stress_test']))
    parameters = fields.List(fields.Nested(SimulationParameterSchema))
    results = fields.Dict(dump_only=True)
    created_by = fields.Integer()
    created_at = fields.DateTime(dump_only=True)
    executed_at = fields.DateTime(dump_only=True)
    execution_time = fields.Float(dump_only=True)
    user = fields.Nested('UserSchema', only=('id', 'username'), dump_only=True)

class SimulationExecuteSchema(Schema):
    id = fields.Integer(required=True)
    parameters = fields.List(fields.Nested(SimulationParameterSchema), allow_none=True)

class SimulationQuerySchema(Schema):
    simulation_type = fields.String(validate=validate.OneOf(['monte_carlo', 'scenario_analysis', 'sensitivity_analysis', 'stress_test']))
    created_by = fields.Integer()
    created_after = fields.DateTime()
    created_before = fields.DateTime()
    executed = fields.Boolean()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['name', 'created_at', 'executed_at']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))
