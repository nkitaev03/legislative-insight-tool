from marshmallow import Schema, fields, validate, validates, ValidationError
from datetime import date

class LegislationSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True, validate=validate.Length(min=3, max=128))
    description = fields.String(required=True)
    jurisdiction = fields.String(validate=validate.Length(max=64))
    effective_date = fields.Date()
    citation = fields.String(validate=validate.Length(max=128))
    url = fields.String(validate=[validate.URL(error="Invalid URL format"), validate.Length(max=256)])
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
    
    @validates('effective_date')
    def validate_effective_date(self, effective_date):
        if effective_date and effective_date > date.today():
            raise ValidationError("Effective date cannot be in the future")

class LegislationQuerySchema(Schema):
    jurisdiction = fields.String()
    effective_after = fields.Date()
    effective_before = fields.Date()
    search = fields.String()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['name', 'jurisdiction', 'effective_date', 'created_at']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))
