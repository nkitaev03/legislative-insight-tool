from marshmallow import Schema, fields, validate

class NewsSchema(Schema):
    id = fields.Integer(dump_only=True)
    title = fields.String(required=True, validate=validate.Length(min=3, max=128))
    content = fields.String(required=True)
    source = fields.String(validate=validate.Length(max=128))
    publication_date = fields.DateTime()
    url = fields.String(validate=[validate.URL(error="Invalid URL format"), validate.Length(max=256)])
    created_at = fields.DateTime(dump_only=True)

class NewsQuerySchema(Schema):
    source = fields.String()
    published_after = fields.DateTime()
    published_before = fields.DateTime()
    search = fields.String()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['title', 'source', 'publication_date', 'created_at']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))
