from marshmallow import Schema, fields, validate
from models import NotificationType

class NotificationSchema(Schema):
    id = fields.Integer(dump_only=True)
    recipient_id = fields.Integer()
    message = fields.String(required=True)
    notification_type = fields.String(validate=validate.OneOf([type.value for type in NotificationType]))
    is_read = fields.Boolean()
    created_at = fields.DateTime(dump_only=True)
    recipient = fields.Nested('UserSchema', only=('id', 'username'), dump_only=True)

class NotificationQuerySchema(Schema):
    is_read = fields.Boolean()
    notification_type = fields.String(validate=validate.OneOf([type.value for type in NotificationType]))
    created_after = fields.DateTime()
    created_before = fields.DateTime()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['created_at']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))

class NotificationUpdateSchema(Schema):
    is_read = fields.Boolean(required=True)
