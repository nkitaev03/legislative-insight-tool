from marshmallow import Schema, fields, validate, validates, ValidationError
from models import RiskStatus, RiskSeverity, RiskLikelihood

class RiskCategorySchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True, validate=validate.Length(min=1, max=64))
    description = fields.String()
    created_at = fields.DateTime(dump_only=True)

class TagSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True, validate=validate.Length(min=1, max=50))

class CommentSchema(Schema):
    id = fields.Integer(dump_only=True)
    content = fields.String(required=True, validate=validate.Length(min=1))
    author_id = fields.Integer(dump_only=True)
    risk_id = fields.Integer(dump_only=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
    author = fields.Nested('UserSchema', only=('id', 'username'), dump_only=True)

class RiskSchema(Schema):
    id = fields.Integer(dump_only=True)
    title = fields.String(required=True, validate=validate.Length(min=3, max=128))
    description = fields.String(required=True)
    status = fields.String(validate=validate.OneOf([status.value for status in RiskStatus]))
    severity = fields.String(validate=validate.OneOf([severity.value for severity in RiskSeverity]))
    likelihood = fields.String(validate=validate.OneOf([likelihood.value for likelihood in RiskLikelihood]))
    impact_score = fields.Float(validate=validate.Range(min=0, max=10))
    risk_score = fields.Float(dump_only=True)
    mitigation_plan = fields.String()
    owner_id = fields.Integer()
    identified_date = fields.DateTime()
    resolution_date = fields.DateTime(allow_none=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
    
    categories = fields.List(fields.Nested(RiskCategorySchema))
    tags = fields.List(fields.Nested(TagSchema))
    comments = fields.List(fields.Nested(CommentSchema), dump_only=True)
    owner = fields.Nested('UserSchema', only=('id', 'username'), dump_only=True)

class RiskQuerySchema(Schema):
    status = fields.String(validate=validate.OneOf([status.value for status in RiskStatus]))
    severity = fields.String(validate=validate.OneOf([severity.value for severity in RiskSeverity]))
    likelihood = fields.String(validate=validate.OneOf([likelihood.value for likelihood in RiskLikelihood]))
    owner_id = fields.Integer()
    category_id = fields.Integer()
    tag_id = fields.Integer()
    min_risk_score = fields.Float(validate=validate.Range(min=0))
    max_risk_score = fields.Float(validate=validate.Range(min=0))
    identified_after = fields.DateTime()
    identified_before = fields.DateTime()
    page = fields.Integer(validate=validate.Range(min=1))
    per_page = fields.Integer(validate=validate.Range(min=1, max=100))
    sort_by = fields.String(validate=validate.OneOf(['created_at', 'updated_at', 'risk_score', 'title']))
    sort_dir = fields.String(validate=validate.OneOf(['asc', 'desc']))
