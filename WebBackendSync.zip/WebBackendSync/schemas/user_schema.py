from marshmallow import Schema, fields, validate, validates, ValidationError
from models import UserRole

class UserSchema(Schema):
    id = fields.Integer(dump_only=True)
    username = fields.String(required=True, validate=validate.Length(min=3, max=64))
    email = fields.Email(required=True)
    password = fields.String(required=True, load_only=True, validate=validate.Length(min=8))
    first_name = fields.String(validate=validate.Length(max=64))
    last_name = fields.String(validate=validate.Length(max=64))
    role = fields.String(validate=validate.OneOf([role.value for role in UserRole]))
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)
    active = fields.Boolean()
    last_login = fields.DateTime(dump_only=True)

    @validates('email')
    def validate_email(self, email):
        if not email or '@' not in email:
            raise ValidationError('Invalid email address.')

class UserUpdateSchema(Schema):
    username = fields.String(validate=validate.Length(min=3, max=64))
    email = fields.Email()
    first_name = fields.String(validate=validate.Length(max=64))
    last_name = fields.String(validate=validate.Length(max=64))
    role = fields.String(validate=validate.OneOf([role.value for role in UserRole]))
    active = fields.Boolean()

class LoginSchema(Schema):
    username = fields.String(required=True)
    password = fields.String(required=True, load_only=True)

class ChangePasswordSchema(Schema):
    current_password = fields.String(required=True, load_only=True)
    new_password = fields.String(required=True, load_only=True, validate=validate.Length(min=8))
    confirm_password = fields.String(required=True, load_only=True, validate=validate.Length(min=8))

    @validates('confirm_password')
    def validate_confirm_password(self, confirm_password, **kwargs):
        if 'new_password' in kwargs['data'] and confirm_password != kwargs['data']['new_password']:
            raise ValidationError('Passwords do not match.')

class TokenSchema(Schema):
    access_token = fields.String(dump_only=True)
    refresh_token = fields.String(dump_only=True)
    token_type = fields.String(dump_only=True)
    expires_in = fields.Integer(dump_only=True)
    
class RefreshTokenSchema(Schema):
    refresh_token = fields.String(required=True)
