from marshmallow import Schema, fields, validate

class RiskAggregationRequestSchema(Schema):
    group_by = fields.String(required=True, validate=validate.OneOf(['severity', 'likelihood', 'status', 'category', 'owner', 'tag']))
    start_date = fields.DateTime()
    end_date = fields.DateTime()
    include_subcategories = fields.Boolean(default=False)

class RiskTrendRequestSchema(Schema):
    time_period = fields.String(required=True, validate=validate.OneOf(['day', 'week', 'month', 'quarter', 'year']))
    metric = fields.String(required=True, validate=validate.OneOf(['count', 'risk_score', 'severity', 'likelihood']))
    category_id = fields.Integer()
    status = fields.String()
    start_date = fields.DateTime()
    end_date = fields.DateTime()

class RiskHeatmapRequestSchema(Schema):
    x_axis = fields.String(required=True, validate=validate.OneOf(['likelihood', 'impact', 'severity']))
    y_axis = fields.String(required=True, validate=validate.OneOf(['likelihood', 'impact', 'severity']))
    filter_category = fields.Integer()
    filter_status = fields.String()

class TopRisksRequestSchema(Schema):
    limit = fields.Integer(validate=validate.Range(min=1, max=50), default=10)
    metric = fields.String(validate=validate.OneOf(['risk_score', 'impact', 'recent']), default='risk_score')
    category_id = fields.Integer()
